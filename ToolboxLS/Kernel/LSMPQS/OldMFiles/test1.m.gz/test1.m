function [ data, g, data0 ] = PolySliceDemo(accuracy)
% polySliceDemo : motion in normal dirction with a curvature term in masked region
% geometry determined from a read in polyethyelene slice

% combination of maskDemo.m, normalStarDemo.m and tripleSine.m examples
%
% [ data, g, data0 ] = PolySliceDemo(accuracy)
%  
% This function was originally designed as a script file, so most of the
%   options can only be modified in the file.
%
% For example, edit the file to change the grid dimension, boundary conditions,
%   flow field parameters, etc.
%
% Parameters:
%
%   accuracy     Controls the order of approximations.
%                  'low'         Use odeCFL1 and upwindFirstFirst (default).
%                  'medium'      Use odeCFL2 and upwindFirstENO2.
%                  'high'        Use odeCFL3 and upwindFirstENO3.
%                  'veryHigh'    Use odeCFL3 and upwindFirstWENO5.
%  
%   data         Implicit surface function at t_max.
%   g            Grid structure on which data was computed.
%   data0        Implicit surface function at t_0.
  
%---------------------------------------------------------------------------
% Make sure we can see the kernel m-files.
run('../addPathToKernel');

%---------------------------------------------------------------------------
% Which of the tasks do you wish to perform?
doMask = 1;
doMin = 0;

% Speed of motion normal to the interface.
aValue = 0.25;

% Set value b
b = 0.025;

if (nargin < 1)
    accuracy = 'medium';
end
    
%---------------------------------------------------------------------------
% Integration parameters.
tMax = 1.0;                  % End time.
plotSteps = 9;               % How many intermediate plots to produce?
t0 = 0;                      % Start time.
singleStep = 0;              % Plot at each timestep (overrides tPlot).

% Period at which intermediate plots should be produced.
tPlot = (tMax - t0) / (plotSteps - 1);

% How close (relative) do we need to get to tMax to be considered finished?
small = 100 * eps;

%---------------------------------------------------------------------------
% What level set should we view?
level = 0;

% Pause after each plot?
pauseAfterPlot = 0;

% Delete previous plot before showing next?
deleteLastPlot = 0;

% Plot in separate subplots (set deleteLastPlot = 0 in this case)?
useSubplots = 1;

%---------------------------------------------------------------------------
% Use periodic boundary conditions?
periodic = 0;

%---------------------------------------------------------------------------
% Create mask by reading in a 2dim rasterfile of a segmented image.
%mask = imread('poly_slice.ras'); % 0 and 1 image
%[m n] = size(mask); % note: should be m=n
%for i=1:n, for j = 1:n, mask(i,j) = 1 - mask(i,j); end, end 

%Create mask by reading in a signed distance function (3dma l2 burn file
%format
fid = fopen('pore_slice_sgn_dist_fun','r');
e  = fread(fid,1,'char');
nx = fread(fid,1,'int');
ny = fread(fid,1,'int'); 
zs = fread(fid,1,'int');
ze = fread(fid,1,'int');

% we assume nx = ny and zs=ze, i.e. 2D data
n = nx;
mask = fread(fid,[n n],'single');
fclose(fid);

% Create the grid. Grid should be determined by the rasterfile size
g.dim = 2;
g.min = 0;
g.dx = 1 / (n-1);
if(periodic)
  g.max = (1 - g.dx);
  g.bdry = @addGhostPeriodic;
else
  g.max = +1;
  g.bdry = @addGhostExtrapolate;
end
g = processGrid(g)

%---------------------------------------------------------------------------
% What kind of display?
switch(g.dim)
   case 1
    displayType = 'plot';
   case 2
    displayType = 'contour';    
   case 3
    displayType = 'surface';
   otherwise
    error('Default display type undefined for dimension %d', g.dim);
end

%---------------------------------------------------------------------------
% Create initial conditions (a hyperplane y=0 at (g.min,0,0).
normal = [ 0.0; 0.1];
point = zeros(g.dim,1);
point(2) = 0.0 + 1/(n-1); % g.min(1) is 0.0
data = shapeHyperplane(g, normal,point);

% Need to ensure that the initial conditions satisfy the mask.
data = max(data, mask);

data0 = data;

plotLevelSetInterior(data,level,mask)
function [ data, g, mask, curv] = CapPressModelimb(accuracy,a0,b,factor,tMax,dxIn,GeomType,...
                                               OutFileName,ICplane,data0In,gIn,maskIn)
% CapPressModel : motion in normal direction and with a curvature term
%
% phi_t(x,t) + a(t)| grad phi(x,t)| = b kappa(phi) |grad phi(x,t)|
% phi - implicit function whose interior represents invading fluid
% _t  denotes temporal derivative
% grad denotes spatial gradient
% kappa denotes curvature
% a(t) is capillary pressure modeled as a(t) = exp(-f*(V(t)- Vmax)/Vmax) where V(t) is 
% volume of the invading fluid at time t, and Vmax the maximal volume the
% fluid could occupy
% f is an arbitary constant that is related to the volume of the invading
% fluid when the equation reaches the steady state

% b is a constant that models surface tension btw invading and resident fluid

% One can pass initial conditions that are final result of the
% previous run.
%  
% Edit the file to change the grid dimension, boundary conditions,
%   flow field parameters, etc.
%
% Parameters:
%
%   accuracy     Controls the order of approximations.
%                  'low'         Use odeCFL1 and upwindFirstFirst (default).
%                  'medium'      Use odeCFL2 and upwindFirstENO2.
%                  'high'        Use odeCFL3 and upwindFirstENO3.
%                  'veryHigh'    Use odeCFL3 and upwindFirstWENO5.
%   a0           constant in the pressure model
%   b            constant that models surface tension
%   factor       constant in the pressure model
%   tMax         max simulation time, default 2.0
%   dx           grid spacing
%   GeomType     options 'Duct2D' (default), 'Sphere2D','Sphere3D','Poly2D'
%   OutFileName  name of the output file, default 'CapPressModel.out'
%   ICplane      Initial Condition plane - 'x' (for x=0 plane), 'y' or 'z'

%  
%   data         Implicit surface function at t_max.
%   g            Grid structure on which data was computed.
%   mask         Different geometries are represented by some of the volume being masked

%---------------------------------------------------------------------------
% Make sure we can see the kernel m-files.
run('../addPathToKernel');
addpath ./InitCond ./MaskGrain ./Model ./Help

%---------------------------------------------------------------------------
% Which of the tasks do you wish to perform?
doMask = 1;
doMin = 0;

AvailGeom = struct('type',{'Duct2D','Sphere2D','Sphere3D','Poly2D'});
MaskGeom  = struct('func',{@MaskDuct2D,@MaskSphere2D,@MaskSphere3D,@MaskPoly2D});

%Sort out input variables
if( nargin < 1 )
    accuracy = 'medium';
end

if( nargin < 2 )
    a0 = 0.02;  %default value
end

if( nargin < 3 )
    b = 0.01; %default value
end

if( nargin < 4 )
    factor = 1; %default value
end

if( nargin < 5 )
    tMax = 2.0;
end

if( nargin < 6 )
    dxIn = 0.04; % default grid spacing
end

if( nargin < 7 )
    GeomType = AvailGeom(1).type;
end;

if( nargin < 8) 
    OutFileName = 'CapPressModel.out'; % output file for curvature results
    fprintf('Default output file is %s.',OutFileName);
end

if( nargin < 9 )
    ICplane = 'x'; % default initial condition is x=0 plane
elseif( (ICplane ~= 'x')&&(ICplane ~= 'y')&&(ICplane ~= 'z'))
    fprintf('Uknown initial condition plane specifier %s, reset to x (x=0)',ICplane);
    ICplane = 'x';
end

testGeom = 0; [m n] = size(AvailGeom);
for i = 1:n
    if( strcmp(GeomType,AvailGeom(i).type) ) 
        testGeom = i;
    end
end

if (testGeom == 0)
    fprintf('Uknown geometry type %s, reset to %s',GeomType,AvailGeom(1).type);
    GeomType = AvailGeom(1).type;
    testGeom = 1;
end

fid = fopen(OutFileName,'w');
fprintf(fid,'Time Start %s\n',datestr(now));
fprintf(fid,'Capillary pressure Level Set Method simulation\n');
fprintf(fid,'Geometry type = %s\n',GeomType);
fprintf(fid,'Initial condition = ''%s=0'' plane\n',ICplane);
fprintf(fid,'Accuracy = %s\n',accuracy);
fprintf(fid,'a = %g\n',a0);
fprintf(fid,'b = %g\n',b);
fprintf(fid,'f = %g\n',factor);

%---------------------------------------------------------------------------
% Integration parameters.
doPlot = 0;                  % Produce intermediate plots?
%plotSteps = 6;               % How many intermediate plots to produce?
                             % if doPlot = 0, this can still be used to
                             % produce some other intermediate results
t0 = 0;                      % Start time.
singleStep = 0;              % Plot at each timestep (overrides tPlot).

% Period at which intermediate plots should be produced.
%tPlot = (tMax - t0) / (plotSteps - 1);
tPlot = 0.5; 
epsStop = 1e-3;

% How close (relative) do we need to get to tMax to be considered finished?
small = 100 * eps;

fprintf(fid,'Simulation continues until given tMax is reached\n'); 
fprintf(fid,'or max.abs.error for data(:,tFinal)-data(:,tFinal-%g)',tPlot);
fprintf(fid,'is less than epsStop.\n',tPlot);
fprintf(fid,'Simulation will also stop if max.abs.error starts increasing.\n');
fprintf(fid,'tMax = %g\n',tMax);
fprintf(fid,'epsStop = %g\n',epsStop);
fprintf(fid,'-------------------------------------------------------------\n');

%---------------------------------------------------------------------------
% What level set should we view?
level = 0;

% Pause after each plot?
pauseAfterPlot = 0;

% Delete previous plot before showing next?
deleteLastPlot = 0;

% Plot in separate subplots (set deleteLastPlot = 0 in this case)?
useSubplots = 1;

%---------------------------------------------------------------------------
% Use periodic boundary conditions?
periodic = 0;


% if initial conditions, grid and mask are not provided then create them
if (nargin < 10)
    % Initialize grid dimensions.
    
    if( testGeom == 3) 
        g.dim = 3;
        g.min = 0 - dxIn;
    elseif( testGeom == 1) 
        g.dim = 2;
        g.min = [-1 - dxIn; 0 - dxIn];
    else
        g.dim = 2;
        g.min = -1 - dxIn;
    end
    
    nx = ceil(1/dxIn); % need to avoid rounding errors
    g.dx = 1/nx; %input value
    
    % create appropriate mask for 'Poly2D' geometry - need to read data
    % before grid is created
    if(testGeom == 4) [mask,g] = feval(MaskGeom(testGeom).func,g); end
    
    % Create grid
    if(periodic)
      g.max = (1 - dxIn);
      g.bdry = @addGhostPeriodic;
    else
      g.max = +1 + dxIn; % extra layer is added to each volume side
      g.bdry = @addGhostExtrapolate;
    end
    g = processGrid(g)

    fprintf(fid,'Grid spacing  dx %g\n',g.dx(1));
    fprintf(fid,'Volume limits [%g,%g]x[%g,%g]\n',g.min(1),g.max(1),g.min(2),g.max(2));
    
    % create appropriate mask
    if(testGeom < 4) [mask,g] = feval(MaskGeom(testGeom).func,g); end
    
    %----------------------------------------------------------------------
    % Create initial conditions
    %pos = min(g.N(1)/2,g.N(2)/2);
    pos = 1;
    data = CreateICimb(g,ICplane,pos);
    %data = circularIC(g);
    
    % Need to ensure that the initial conditions satisfy the mask.
    data = max(data, mask);
    data0 = data;
    
else
    data0 = data0In;
    data  = data0In;
    g     = gIn;
    mask  = maskIn;
end

%---------------------------------------------------------------------------
% What kind of display?
switch(g.dim)
   case 1
    displayType = 'plot';
   case 2
    displayType = 'contour';    
   case 3
    displayType = 'surface';
   otherwise
    error('Default display type undefined for dimension %d', g.dim);
end

%---------------------------------------------------------------------------
% Set up time approximation scheme.
integratorOptions = odeCFLset('factorCFL', 0.5, 'stats', 'on');

% Choose approximations at appropriate level of accuracy.
%   Same accuracy is used by both components of motion.
switch(accuracy)
 case 'low'
  derivFunc = @upwindFirstFirst;
  integratorFunc = @odeCFL1;
 case 'medium'
  derivFunc = @upwindFirstENO2;
  integratorFunc = @odeCFL2;
 case 'high'
  derivFunc = @upwindFirstENO3;
  integratorFunc = @odeCFL3;
 case 'veryHigh'
  derivFunc = @upwindFirstWENO5;
  integratorFunc = @odeCFL3;
 otherwise
  error('Unknown accuracy level %s', accuracy);
end

if(singleStep)
  integratorOptions = odeCFLset(integratorOptions, 'singleStep', 'on');
end

% get initial volume of the invading fluid 
volume0 = size(find(data0 < 0 ));
volume0 = volume0(1);

% get max. possible volume of the invading fluid
%if( g.dim == 3 )
    volume_max = size(find(mask < 0 ));
    volume_max = volume_max(1)
%else
 %   volume_max = areaLevelSetInterior(mask,g);
%end

%---------------------------------------------------------------------------
% Set up basic motion in the normal direction.
normalFunc = @termNormal;
normalData.grid = g;
normalData.speed = @PressureModelVmax; % handle to the function that computes normal speed a(t)
normalData.magnitude = a0;
normalData.derivFunc = derivFunc;
normalData.v0 = volume0;      % used in PressureModelVmax
vol_factor = 0.75;
normalData.vmax = vol_factor*volume_max; % used in PressureModelVmax
normalData.factor = factor;   % used in PressureModelVmax

%---------------------------------------------------------------------------
% Set up curvature motion.
curvatureFunc = @termCurvature;
curvatureData.grid = g;
curvatureData.curvatureFunc = @curvatureSecond;
curvatureData.b = b;

%---------------------------------------------------------------------------
% Combine components of motion.
if(b > 0)
  % If there is a nonzero curvature contribution to speed.
  schemeFunc = @termSum;
  schemeData.innerFunc = { normalFunc; curvatureFunc };
  schemeData.innerData = { normalData; curvatureData };
else
  % Otherwise ignore curvature.
  schemeFunc = normalFunc;
  schemeData = normalData;
end

%delete structures that are not needed for memory efficiency
clear normalData;
clear curvatureData;

%---------------------------------------------------------------------------
% Set up data required for the mask operation.
%   Mask will be compared to vector form of data array used by integrator.
schemeData.mask = mask(:);
schemeData.doMask = doMask;

% Also keep track of minimum of phi over time.
%   Minimum will be kept in vector form used by integrator.
schemeData.min = data(:);
schemeData.doMin = doMin;

% Let the integrator know what function to call.
integratorOptions = odeCFLset(integratorOptions, ...
                              'postTimestep', @maskAndKeepMin);

if( doPlot)                         
    %---------------------------------------------------------------------------
    % Initialize Display
    f = figure;

    % Set up subplot parameters if necessary.
    if(useSubplots)
      rows = ceil(sqrt(plotSteps));
      cols = ceil(plotSteps / rows);
      plotNum = 1;
      subplot(rows, cols, plotNum);
    end

    h = visualizeLevelSet(g, data, displayType, level, [ 't = ' num2str(t0) ]);
    %plotLevelSetInterior(data,level,mask)

    hold on;
    if(g.dim > 1)
      axis(g.axis);
      daspect([ 1 1 1 ]);
    end
end

%---------------------------------------------------------------------------
% Loop until tMax (subject to a little roundoff) or max_abs_error is
% satisfactory or max_abs_error starts increasing
tNow = t0;
startTime = cputime;
max_abs_err = 1000.0;
go_on = 1;

while( go_on )
  
  % Reshape data array into column vector for ode solver call.
  y0 = data(:);

  % How far to step?
  tSpan = [ tNow, min(tMax, tNow + tPlot) ];
  
  % Take a timestep.
  %   Record returned schemeData structure to keep track of min over time.
  [ t y schemeData ] = feval(integratorFunc, schemeFunc, tSpan, y0,...
                             integratorOptions, schemeData);
  
  max_abs_err_old = max_abs_err;                           
  max_abs_err = max(abs(y - y0));
  fprintf('Time interval [%g,%g], max_abs error %g\n', tNow,t(end),max_abs_err);
  fprintf(fid,'Time interval [%g,%g], max_abs error %g\n', tNow,t(end),max_abs_err);
  tNow = t(end);
  
  % Get back the correctly shaped data array
  data = reshape(y,g.shape);
  data_old = reshape(y0,g.shape);

  non_empty = size( find (y > 0 ) ); non_empty = non_empty(1);
  
  go_on = (tMax - tNow > small * tMax) & (max_abs_err > epsStop) & (max_abs_err < max_abs_err_old) & non_empty;
  if(max_abs_err == max_abs_err_old)
      fprintf('Possibly stuck with too small tPlot=%g, increase and rerun.',tPlot);
  end
  
  if( doPlot)
      if(pauseAfterPlot)
        % Wait for last plot to be digested.
        pause;
      end

      % Get correct figure, and remember its current view.
      figure(f);
      figureView = view;

      % Delete last visualization if necessary.
      if(deleteLastPlot)
        delete(h);
      end

      % Move to next subplot if necessary.
      if(useSubplots)
        plotNum = plotNum + 1;
        subplot(rows, cols, plotNum);
      end

      % Create new visualization.
      h = visualizeLevelSet(g, data, displayType, level, [ 't = ' num2str(tNow) ]);
      %plotLevelSetInterior(data,level,mask)

      % Restore view.
      view(figureView);
  end
end

%---------------------------------------------------------------------------
endTime = cputime;
fprintf('Total execution time %g seconds', endTime - startTime);
fprintf(fid,'Total execution time %g seconds\n', endTime - startTime);

disp('Memory usage after main loop'); whos
s = whos;
[n m]= size(s); mem=0;
for i=1:n, mem=mem+s(i).bytes; end
%fprintf('Total memory used (after main loop) %g bytes',mem);
fprintf(fid,'Total memory used (after main loop) %g bytes\n',mem);

%---------------------------------------------------------------------------


% Process and display final results.
%minOverTime = reshape(schemeData.min, g.shape);

if(g.dim == 2)
  % Display initial set, mask, minimum over time, and final set.
  figure;
  lev = [ level level ];
  [ garbage, hI ] = contour(g.xs{1}, g.xs{2}, data0, lev, 'b--');
  hold on;
  [ garbage, hF ] = contour(g.xs{1}, g.xs{2}, data, lev, 'r-');
  %[ garbage, hT ] = contour(g.xs{1}, g.xs{2}, minOverTime, lev, 'k:');
  [ garbage, hT ] = contour(g.xs{1}, g.xs{2}, data_old, lev, 'k:');
  [ garbage, hM ] = contour(g.xs{1}, g.xs{2}, mask, lev, 'g-.');
  
  hs = [ hI; hF; hT; hM ];

  set(hs, 'LineWidth', 2.0);

  legend([ hI(1), hF(1), hT(1), hM(1) ], ...
         {'initial', 'final', 'plotStep before final', 'mask'}, 2);
         % {'initial', 'final', 'minOverTime', 'mask'}, 2);
  axis equal
  axis(g.axis);
else
  warning('Cannot create final plot in dimensions other than 2D');
end

 %compute current curvature
 [curv grad] = curvatureSecond(g, data);
 k_avg = displayCurvature(data,g,mask,curv,fid);

 %max absolute error
 max_abs_err = max(max( abs(data - data_old)));
 fprintf(fid,'Max abs difference in  (data(:,%g) - data(:,%g)) everywhere\n',tNow,tNow-tPlot);
 fprintf(fid,'\t%g\n',max_abs_err);
  
 %output current volume of the fluid occupied part 
 volume = size(find(data < 0 ));
 volume = volume(1)
 fprintf(fid,'Invading fluid volume\n\tV(tMax) = %g, fraction total %g\n',volume,volume/volume_max);
 fprintf(fid,'Maximal void space volume\n\tVolMax %g\n',volume_max);
 fprintf(fid,'Maximal volume in a(t) model\n\tVmax = %g\n',vol_factor*volume_max);
 
 %output current a
 rel_change = (volume - 0.75*volume_max)/(0.75*volume_max);
 norm_speed =  a0 * exp(-factor*rel_change);
 fprintf(fid,'Normal speed\n\ta(tMax) = %g\n',norm_speed);
 fprintf(fid,'Curvature term\n\tb*k_avg = %g\n',b*k_avg);

 fprintf(fid,'Time End %s\n',datestr(now));
 
 fclose(fid);
 rmpath ./InitCond ./MaskGrain ./Model ./Help;


%---------------------------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%---------------------------------------------------------------------------
function [ yOut, schemeDataOut ] = maskAndKeepMin(t, yIn, schemeDataIn)
% maskAndKeepMin: Example postTimestep processing routine.
%
%  [ yOut, schemeDataOut ] = maskAndKeepMin(t, yIn, schemeDataIn)
%
%  This function demonstrates two entirely different processes that
%    can be accomplished through the postTimestep odeCFLn integrator option.
%
%  The first is to mask the evolving implicit surface function
%    (or otherwise modify its value after each timestep).
%
%  In this case masking is accomplished by
%
%          yOut = max(yIn, schemeDataIn.mask);
%
%
%   which ensures that phi cannot be negative anywhere that mask is positive.
%
%  The second is to keep track of some feature of that implicit surface
%    function or otherwise modify the schemeData structure after each
%    timestep.
%
%  In this case the feature recorded is the pointwise minimum over time of phi
%
%          schemeDataOut.min = min(yIn, schemeDataIn.min);
%
%
% Parameters:
%   t              Current time.
%   yIn            Input version of the level set function, in vector form.
%   schemeDataIn   Input version of a structure (see below).
%
%   yOut           Output version of the level set function, in vector form.
%   schemeDataOut  Output version of the structure (possibly modified).
%
% schemeData is a structure containing data specific to this type of 
%   term approximation.  For this function it contains the field(s)
%
%   .doMask      Boolean specifying whether masking should be performed.
%   .doMin       Boolean specifying whether min should be taken.
%   .mask	 Function against which to mask the level set function.
%   .min         Function which stores the minimum of the level set
%                  function over time (it is modified at each timestep).
%
% schemeData may contain other fields.

  checkStructureFields(schemeDataIn, 'doMask', 'doMin');

  % Mask the current level set function.
  if(schemeDataIn.doMask)
    checkStructureFields(schemeDataIn, 'mask');
    yOut = max(yIn, schemeDataIn.mask);
  else
    yOut = yIn;
  end

  % Record any new minimum values for each node.
  %   Use yOut to get the masked version of the data (if masking).
  schemeDataOut = schemeDataIn;
  if(schemeDataIn.doMin)
    checkStructureFields(schemeDataIn, 'min');
    schemeDataOut.min = min(yOut, schemeDataOut.min);
  end

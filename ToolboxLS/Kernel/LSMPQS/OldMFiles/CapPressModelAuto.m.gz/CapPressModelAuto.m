function [ data, g, mask, curv] = CapPressModelAuto(accuracy,tMax,dxIn,GeomType,...
                                               OutFileName,ICplane,data0In,gIn,maskIn)
% CapPressModel : motion in normal direction and with a curvature term
%
% phi_t(x,t) + a(t)| grad phi(x,t)| = b kappa(phi) |grad phi(x,t)|
% phi - implicit function whose interior represents invading fluid
% _t  denotes temporal derivative
% grad denotes spatial gradient
% kappa denotes curvature
% a(t) is capillary pressure modeled as a(t) = exp(-f*(V(t)- Vmax)/Vmax) where V(t) is 
% volume of the invading fluid at time t, and Vmax the maximal volume the
% fluid could occupy
% f is an arbitary constant that is related to the volume of the invading
% fluid when the equation reaches the steady state

% b is a constant that models surface tension btw invading and resident fluid

% One can pass initial conditions that are final result of the
% previous run.
%  
% Edit the file to change the grid dimension, boundary conditions,
%   flow field parameters, etc.
%
% Parameters:
%
%   accuracy     Controls the order of approximations.
%                  'low'         Use odeCFL1 and upwindFirstFirst (default).
%                  'medium'      Use odeCFL2 and upwindFirstENO2.
%                  'high'        Use odeCFL3 and upwindFirstENO3.
%                  'veryHigh'    Use odeCFL3 and upwindFirstWENO5.
%   a0           constant in the pressure model
%   b            constant that models surface tension
%   factor       constant in the pressure model
%   Vmax_frac    target volume as a fraction of available pore space
%   tMax         max simulation time, default 2.0
%   dx           grid spacing
%   GeomType     options 'Duct2D' (default), 'Sphere2D','Sphere3D','Poly2D'
%   OutFileName  name of the output file, default 'CapPressModel.out'
%   ICplane      Initial Condition plane - 'x' (for x=0 plane), 'y' or 'z'

%  
%   data         Implicit surface function at t_max.
%   g            Grid structure on which data was computed.
%   mask         Different geometries are represented by some of the volume being masked

%---------------------------------------------------------------------------
% Make sure we can see the kernel m-files.
run('../addPathToKernel');
addpath ./InitCond ./MaskGrain ./Model ./Help

%---------------------------------------------------------------------------
% Which of the tasks do you wish to perform?
doMask = 1;
doMin = 0;

[AvailGeom, MaskGeom] = SetAvailGeom;

%Sort out input variables
if( nargin < 1 )
    accuracy = 'medium';
end

if( nargin < 2 )
    tMax = 2.0;
end

if( nargin < 3 )
    dxIn = 0.04; % default grid spacing
end

if( nargin < 4 )
    GeomType = AvailGeom(1).type;
end;

if( nargin < 5) 
    OutFileName = 'CapPressModel.out'; % output file for curvature results
    fprintf('Default output file is %s.',OutFileName);
end

if( nargin < 6 )
    ICplane = 'x'; % default initial condition is x=0 plane
elseif( (ICplane ~= 'x')&&(ICplane ~= 'y')&&(ICplane ~= 'z'))
    fprintf('Uknown initial condition plane specifier %s, reset to x (x=0)',ICplane);
    IClane = 'x';
end

testGeom = 0; [m n] = size(AvailGeom);
for i = 1:n
    if( strcmp(GeomType,AvailGeom(i).type) ) 
        testGeom = i;
    end
end

if (testGeom == 0)
    fprintf('Uknown geometry type %s, reset to %s',GeomType,AvailGeom(1).type);
    GeomType = AvailGeom(1).type;
    testGeom = 1;
end

b = 0.05; % set constant
factor = 1.5;

fid = fopen(OutFileName,'w');
fprintf(fid,'Time Start %s\n',datestr(now));
fprintf(fid,'Capillary pressure Level Set Method simulation\n');
fprintf(fid,'Geometry type = %s\n',GeomType);
fprintf(fid,'Initial condition = ''%s=0'' plane\n',ICplane);
fprintf(fid,'Accuracy = %s\n',accuracy);

fprintf(fid,'b = %g\n',b);
fprintf(fid,'f = %g\n',factor);


%---------------------------------------------------------------------------
% Integration parameters.
singleStep = 0;              % Plot at each timestep (overrides tPlot).

% Period at which intermediate plots should be produced.
%tPlot = (tMax - t0) / (plotSteps - 1);
tPlot = 0.5; 
epsStop = 1e-3;

% How close (relative) do we need to get to tMax to be considered finished?
small = 100 * eps;

fprintf(fid,'Simulation continues until given tMax is reached\n'); 
fprintf(fid,'or max.abs.error for data(:,tFinal)-data(:,tFinal-%g)',tPlot);
fprintf(fid,'is less than epsStop.\n',tPlot);
fprintf(fid,'Simulation will also stop if max.abs.error starts increasing.\n');
fprintf(fid,'tMax = %g\n',tMax);
fprintf(fid,'epsStop = %g\n',epsStop);
fprintf(fid,'-------------------------------------------------------------\n');

%---------------------------------------------------------------------------
% What level set should we view?
level = 0;

%---------------------------------------------------------------------------
% Use periodic boundary conditions?
periodic = 0;

% if initial conditions, grid and mask are not provided then create them
if (nargin < 7)
    % Initialize grid dimensions.
    [data, data0, g] = InitializeDataGrid(mask,dxIn,testGeom,MaskGeom,ICplane,periodic);
else
    data0 = data0In;
    data  = data0In;
    g     = gIn;
    mask  = maskIn;
end

fprintf(fid,'Grid spacing  dx %g\n',g.dx(1));
fprintf(fid,'Volume limits [%g,%g]x[%g,%g]\n',g.min(1),g.max(1),g.min(2),g.max(2));

%---------------------------------------------------------------------------
% What kind of display?
switch(g.dim)
   case 1
    displayType = 'plot';
   case 2
    displayType = 'contour';    
   case 3
    displayType = 'surface';
   otherwise
    error('Default display type undefined for dimension %d', g.dim);
end

%---------------------------------------------------------------------------
% Set up time approximation scheme.
integratorOptions = odeCFLset('factorCFL', 0.5, 'stats', 'on');

% Choose approximations at appropriate level of accuracy.
%   Same accuracy is used by both components of motion.
switch(accuracy)
 case 'low'
  derivFunc = @upwindFirstFirst;
  integratorFunc = @odeCFL1;
 case 'medium'
  derivFunc = @upwindFirstENO2;
  integratorFunc = @odeCFL2;
 case 'high'
  derivFunc = @upwindFirstENO3;
  integratorFunc = @odeCFL3;
 case 'veryHigh'
  derivFunc = @upwindFirstWENO5;
  integratorFunc = @odeCFL3;
 otherwise
  error('Unknown accuracy level %s', accuracy);
end

if(singleStep)
  integratorOptions = odeCFLset(integratorOptions, 'singleStep', 'on');
end

% get initial volume of the invading fluid 
volume0 = size(find(data0 < 0 ));
volume0 = volume0(1)

% get max. possible volume of the invading fluid
%if( g.dim == 3 )
    volume_max = size(find(mask < 0 ));
    volume_max = volume_max(1)
%else
%   volume_max = areaLevelSetInterior(mask,g); % something ain't right for
%   sphere2D
%end

% Figure out entry conditions
size(find(mask(1,:) < 0 ))
size(find(mask(:,1) < 0 ))
%IC is set so there is one layer of voxels
Rt = 0.5 * volume0  % entry throat radius in grid points
volume_entry = 0.5 * (Rt*Rt*pi); % area of entry half-circle
Vmax_frac = volume_entry / volume_max; %corresponding volume fraction

%breakthrough (critical) pressure
a0 = b * (2/(Rt*g.dx(1)));
da = 0.02*a0;
amax = 1.5*a0;

fprintf(fid,'\nEntry Rt %g, entry pressure a0 = b * (2/Rt) = %g',Rt*g.dx(1),a0);
fprintf(fid,'\nPressure increment da = %d\n',da);

if(g.dim == 2)
  % Display initial set, mask
  figure;
  lev = [ level level ];
  [ garbage, hI ] = contour(g.xs{1}, g.xs{2}, data0, lev, 'b--');
  hold on;
  [ garbage, hM ] = contour(g.xs{1}, g.xs{2}, mask, lev, 'g-.');
  
  hs = [ hI; hM ];

  set(hs, 'LineWidth', 2.0);

  legend([ hI(1), hM(1) ], ...
         {'initial','mask'}, 2)
  axis equal
  axis(g.axis);
else
  warning('Cannot create final plot in dimensions other than 2D');
end

step = 1;
save data_init data0
save mask mask
save grid g

while( step <= 1  )
    
    fprintf(fid,'\nStep %g',step);
    fprintf(fid,'\na0 = %g, Vmax_frac %g',a0,Vmax_frac);
    %---------------------------------------------------------------------------
    % Set up basic motion in the normal direction.
    normalFunc = @termNormal;
    normalData.grid = g;
    normalData.speed = @PressureModelVmax; % handle to the function that computes normal speed a(t)
    normalData.magnitude = a0;
    normalData.derivFunc = derivFunc;
    normalData.v0 = volume0;      % used in PressureModelVmax
    vol_factor = Vmax_frac;
    normalData.vmax = vol_factor*volume_max; % used in PressureModelVmax
    normalData.factor = factor;   % used in PressureModelVmax

    %---------------------------------------------------------------------------
    % Set up curvature motion.
    curvatureFunc = @termCurvature;
    curvatureData.grid = g;
    curvatureData.curvatureFunc = @curvatureSecond;
    curvatureData.b = b;

    %---------------------------------------------------------------------------
    % Combine components of motion.
    if(b > 0)
      % If there is a nonzero curvature contribution to speed.
      schemeFunc = @termSum;
      schemeData.innerFunc = { normalFunc; curvatureFunc };
      schemeData.innerData = { normalData; curvatureData };
    else
      % Otherwise ignore curvature.
      schemeFunc = normalFunc;
      schemeData = normalData;
    end

    %---------------------------------------------------------------------------
    % Set up data required for the mask operation.
    %   Mask will be compared to vector form of data array used by integrator.
    schemeData.mask = mask(:);
    schemeData.doMask = doMask;

    % Also keep track of minimum of phi over time.
    %   Minimum will be kept in vector form used by integrator.
    schemeData.min = data(:);
    schemeData.doMin = doMin;

    % Let the integrator know what function to call.
    integratorOptions = odeCFLset(integratorOptions, ...
                                  'postTimestep', @maskAndKeepMin);

    %---------------------------------------------------------------------------
    % Loop until tMax (subject to a little roundoff) or max_abs_error is
    % satisfactory or max_abs_error starts increasing
    tNow = 0;
    startTime = cputime;
    max_abs_err = 1000.0;
    go_on = 1;

    while( go_on )

      % Reshape data array into column vector for ode solver call.
      y0 = data(:);

      % How far to step?
      tSpan = [ tNow, min(tMax, tNow + tPlot) ];

      % Take a timestep.
      %   Record returned schemeData structure to keep track of min over time.
      [ t y schemeData ] = feval(integratorFunc, schemeFunc, tSpan, y0,...
                                 integratorOptions, schemeData);

      max_abs_err_old = max_abs_err;                           
      max_abs_err = max(abs(y - y0));
      fprintf('Time interval [%g,%g], max_abs error %g\n', tNow,t(end),max_abs_err);
      fprintf(fid,'Time interval [%g,%g], max_abs error %g\n', tNow,t(end),max_abs_err);
      tNow = t(end);

      % Get back the correctly shaped data array
      data = reshape(y,g.shape);
      data_old = reshape(y0,g.shape);

      non_empty = size( find (y > 0 ) ); non_empty = non_empty(1);

      go_on = (tMax - tNow > small * tMax) & (max_abs_err > epsStop) & (max_abs_err < max_abs_err_old) & non_empty;
      if(max_abs_err == max_abs_err_old)
          fprintf('tPlot=%g possibly too small, increase and rerun.',tPlot);
      end
    end

    %---------------------------------------------------------------------------
    endTime = cputime;
    fprintf('Execution time %g seconds', endTime - startTime);
    fprintf(fid,'Execution time %g seconds\n', endTime - startTime);
    
    %max absolute error
     max_abs_err = max(max( abs(data - data_old)));
     fprintf(fid,'Max abs difference in  (data(:,%g) - data(:,%g)) everywhere\n',tNow,tNow-tPlot);
     fprintf(fid,'\t%g\n',max_abs_err);

     %output current volume of the fluid occupied part 
     volume = size(find(data < 0 ));
     volume = volume(1)
     fprintf(fid,'Invading fluid volume\n\tV(tMax) = %g, fraction total %g\n',volume,volume/volume_max);
     fprintf(fid,'Maximal void space volume\n\tVolMax %g\n',volume_max);
     fprintf(fid,'Maximal volume in a(t) model\n\tVmax = %g\n',vol_factor*volume_max);

     %output current a
     rel_change = (volume - Vmax_frac*volume_max)/(Vmax_frac*volume_max);
     norm_speed =  a0 * exp(-factor*rel_change);
     fprintf(fid,'Normal speed\n\ta(tMax) = %g\n',norm_speed);
     %fprintf(fid,'Curvature term\n\tb*k_avg = %g\n',b*k_avg);
     
     fprintf(fid,'-------------------------------------------\n');
    
     if( g.dim == 2)
        if ( ceil(step/2) == step/2 )
            [ garbage, hF ] = contour(g.xs{1}, g.xs{2}, data, lev, 'r-'); hold on;
        else
            [ garbage, hF ] = contour(g.xs{1}, g.xs{2}, data, lev, 'k-'); hold on;
        end
        
        set(hF, 'LineWidth', 2.0);
        axis equal
        axis(g.axis);
     end
    
    
    %compute current curvature
    %[curv grad_norm_data] = curvatureSecond(g,data);
 
    %k_avg = displayCurvature(data,g,mask,curv,fid);
 
    data0 = data;
    if (step > 1) a0 = a0 + da;  end
    %if (step > 1) Vmax_frac = 1.0;
    %else          Vmax_frac = 0.5; %only for step 2
    %end
    
    f = 0.05; Vmax_frac = 0.5;
    
    fname = sprintf('data_step%d',step);
    save(fname,'data');
    
    step = step+1;
    if( volume == volume_max ) % we invaded  entire available space 
        a0 = amax+1; % this will efectively stop iteration
    end
end

hold off;

disp('Memory usage after main loop'); whos
s = whos;
[n m]= size(s); mem=0;
for i=1:n, mem=mem+s(i).bytes; end
%fprintf('Total memory used (after main loop) %g bytes',mem);
fprintf(fid,'Total memory used (after main loop) %g bytes\n',mem);

%---------------------------------------------------------------------------
 
 
 fprintf(fid,'Time End %s\n',datestr(now));
 
 fclose(fid);
 rmpath ./InitCond ./MaskGrain ./Model ./Help;
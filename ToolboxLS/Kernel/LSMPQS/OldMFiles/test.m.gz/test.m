
run('../addPathToKernel');

%---------------------------------------------------------------------------
% Create mask by reading in a 2dim rasterfile of a segmented image.
%mask = imread('poly_slice.ras'); % 0 and 1 image
%[m n] = size(mask); % note: should be m=n
%for i=1:n, for j = 1:n, mask(i,j) = 1 - mask(i,j); end, end 

%Create mask by reading in a signed distance function (3dma l2 burn file
%format
fid = fopen('pore_slice_sgn_dist_fun','r');
e  = fread(fid,1,'char');
nx = fread(fid,1,'int');
ny = fread(fid,1,'int'); 
zs = fread(fid,1,'int');
ze = fread(fid,1,'int');

% we assume nx = ny and zs=ze, i.e. 2D data
n = nx;
mask = fread(fid,[n n],'single');
fclose(fid);

periodic = 0;

% Create the grid. Grid should be determined by the rasterfile size
g.dim = 2;
g.min = 0;
g.dx = 1 / (n-1);
if(periodic)
  g.max = (1 - g.dx);
  g.bdry = @addGhostPeriodic;
else
  g.max = +1;
  g.bdry = @addGhostExtrapolate;
end
g = processGrid(g)


%level = 0;
%lev = [ level level ];
%[ garbage, hM ] = contour(g.xs{1}, g.xs{2}, mask, lev, 'g-.');

%---------------------------------------------------------------------------
% Create initial conditions (a hyperplane y=0 at (g.min,0,0).
normal = [ 0.0; 0.1];
point = zeros(g.dim,1);
point(2) = 0.0 + 1/(n-1); % g.min(1) is 0.0
data = shapeHyperplane(g, normal,point);


% Need to ensure that the initial conditions satisfy the mask.
data = max(data, mask);

data0 = data;

plotLevelSetInterior(data,0,mask)
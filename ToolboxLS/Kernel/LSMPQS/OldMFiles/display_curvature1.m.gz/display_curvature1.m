function K = display_curvature1(data,g,mask,curv,OutFile)

% K = display_curvature1(data,g,mask,curv,OutFile)
% data - level set function, will plot curvature values in 'curv' on its level = 0
% g - grid
% mask - level set function defining pore and grain space
% curv - curvature data
% Outfile, if supplied, will be appended with curvature average, min, max.

%compute current curvature
 C = contour(data,[0 0]); % find a 0-level set and output coords to matrix C
 Cmask = contour(mask,[0 0]);
 
 n = C(2,1); m = Cmask(2,1); % number of points on each level set
 % get the coordinates
 x = C(1,2:(n+1));
 y = C(2,2:(n+1));
 
 xmask = Cmask(1,2:(n+1));
 ymask = Cmask(2,2:(n+1));
 
 tmp = ismember(x,xmask) & ismember(y,ymask);
 tmp = 1 - tmp;
 fld_intfc = find(tmp > 0);
 
 x_fld = x(fld_intfc);
 y_fld = y(fld_intfc); y_fld = y_fld';
 
 %find interpolated curvature values at these coords
 curv_interp = interp2(curv,x_fld,y_fld); % this creates interpolated values on entire grid defined by x,y
 K = diag(curv_interp); %isolate only values at (x_fld(i),y_fld(i))
 sz = size(K); sz = sz(1);
 
 k_avg_fld_intfc = mean(K)
 k_min_fld_intfc = min(K)
 k_max_fld_intfc = max(K)
 
 [M N] = size(data);
 y_fld = y_fld';
 I = find( (x_fld >= 5) & (x_fld <= N-5) & (y_fld >= 5) & (y_fld <= M-5) ); %5 grid points away from volume sides; works well for duct
 y_fld = y_fld';
 K1 = K(I); 
  
 sz1 = size(K1); sz1 = sz1(1);
 k_avg = mean(K1) 
 k_min = min(K1) 
 k_max = max(K1)
 
 if (nargin >= 5)
     fid = fopen(OutFile,'a');
     fprintf(fid,'Fluid interface curvature ( data = 0) & (mask < 0) - %d values\n',sz);
     fprintf(fid,'\tk_avg_fld_intfc %g\n',k_avg_fld_intfc);
     fprintf(fid,'\tk_min_fld_intfc %g\n',k_min_fld_intfc);
     fprintf(fid,'\tk_max_fld_intfc %g\n',k_max_fld_intfc);
      fprintf(fid,'Fluid interface curvature values 5 grid pts away from volume bdry - %d values\n',sz1);
     fprintf(fid,'\tk_avg %g\n',k_avg);
     fprintf(fid,'\tk_min %g\n',k_min);
     fprintf(fid,'\tk_max %g\n',k_max);
     
 end
 
 if(g.dim == 2)
     %plot curvature  
     figure,plot3(y_fld,x_fld,K,'.'),xlabel('x'), ylabel('y'), zlabel('fld intfc curvature')
     axis([0 g.N(1) 0 g.N(2) k_min_fld_intfc k_max_fld_intfc])
 end
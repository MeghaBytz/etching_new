function [ data, g, data0 ] = Sphere3D(accuracy)
% newDemo : motion in normal dirction with a curvature term in masked region 
%
% combination of maskDemo.m, normalStarDemo.m and tripleSine.m examples
% pore space is in between 3 2D spheres
%
% [ data, g, data0 ] = SphereDemo(accuracy)
%  
% This function was originally designed as a script file, so most of the
%   options can only be modified in the file.
%
% For example, edit the file to change the grid dimension, boundary conditions,
%   flow field parameters, etc.
%
% Parameters:
%
%   accuracy     Controls the order of approximations.
%                  'low'         Use odeCFL1 and upwindFirstFirst (default).
%                  'medium'      Use odeCFL2 and upwindFirstENO2.
%                  'high'        Use odeCFL3 and upwindFirstENO3.
%                  'veryHigh'    Use odeCFL3 and upwindFirstWENO5.
%  
%   data         Implicit surface function at t_max.
%   g            Grid structure on which data was computed.
%   data0        Implicit surface function at t_0.
  
%---------------------------------------------------------------------------
% Make sure we can see the kernel m-files.
run('../addPathToKernel');

%---------------------------------------------------------------------------
% Which of the tasks do you wish to perform?
doMask = 1;
doMin = 0;

% Speed of motion normal to the interface.
aValue = 0.25;

% Set value b
b = 0.025;

if (nargin < 1)
    accuracy = 'medium';
end
    
%---------------------------------------------------------------------------
% Integration parameters.
tMax = 0.5;                  % End time.
plotSteps = 4;               % How many intermediate plots to produce?
t0 = 0;                      % Start time.
singleStep = 0;              % Plot at each timestep (overrides tPlot).

% Period at which intermediate plots should be produced.
tPlot = (tMax - t0) / (plotSteps - 1);

% How close (relative) do we need to get to tMax to be considered finished?
small = 100 * eps;

%---------------------------------------------------------------------------
% What level set should we view?
level = 0;

% Pause after each plot?
pauseAfterPlot = 0;

% Delete previous plot before showing next?
deleteLastPlot = 0;

% Plot in separate subplots (set deleteLastPlot = 0 in this case)?
useSubplots = 0;

%---------------------------------------------------------------------------
% Use periodic boundary conditions?
periodic = 0;

% radius of a sphere
r = 1;

% number of grid intervals in each dimension
nx = 50;

% Create the grid.
% we'll work in [0,2r]x[0,2r]x[0,2r]
g.dim = 3;
g.min = 0;
g.dx = 1 / nx;
if(periodic)
  g.max = (1 - g.dx);
  g.bdry = @addGhostPeriodic;
else
  g.max = 2*r;
  g.bdry = @addGhostExtrapolate;
end
g = processGrid(g)

%---------------------------------------------------------------------------
% What kind of display?
switch(g.dim)
   case 1
    displayType = 'plot';
   case 2
    displayType = 'contour';    
   case 3
    displayType = 'surface';
   otherwise
    error('Default display type undefined for dimension %d', g.dim);
end

% Create geometry - 4 spheres of radius r have centers at columns of
% maskCenter
a = 2*r;
v = a*sqrt(3)/2.0;
k = a *sqrt(2.0/3.0);
maskCenter = [0 0 0; a 0 0; a/2 v 0; a/2 v/3 k];
maskCenter = maskCenter';

%---------------------------------------------------------------------------
% Create initial conditions - hyperplane z=0
normal = [0.0; 0.0; 1.0];
point =  [0.0; 0.0; 1/nx];
data = shapeHyperplane(g,normal,point);


%---------------------------------------------------------------------------
% Create mask (4 spheres and 3 hyperplanes)
n = 4;  % number of masking spheres

% The moving set can be anywhere outside the masked region.
%  '-' sign is to get the complement of the masked region.
mask = - shapeSphere(g, maskCenter(:,1), r);
%figure, visualizeLevelSet(g, mask, displayType, level, [ 't = ' num2str(t0) ]);

for i=2:n
  mask = max(mask,-shapeSphere(g, maskCenter(:,i),r));
   %figure, visualizeLevelSet(g, mask, displayType, level, [ 't = ' num2str(t0) ]);
end

point0 = maskCenter(:,4);
for i=1:(n-1)
   point1 = maskCenter(:,i);
   if ( i == 3) point2 = maskCenter(:,1);
   else point2 = maskCenter(:,i+1);
   end
   
   A = point1 - point0;
   B = point2 - point0;
   normal = cross(A,B);
   normal = normal/norm(normal);
   
   mask = max(mask,shapeHyperplane(g,normal,point0));
end


% Need to ensure that the initial conditions satisfy the mask.
data = max(data, mask);

data0 = data;

%---------------------------------------------------------------------------
% Set up time approximation scheme.
integratorOptions = odeCFLset('factorCFL', 0.5, 'stats', 'on');

% Choose approximations at appropriate level of accuracy.
%   Same accuracy is used by both components of motion.
switch(accuracy)
 case 'low'
  derivFunc = @upwindFirstFirst;
  integratorFunc = @odeCFL1;
 case 'medium'
  derivFunc = @upwindFirstENO2;
  integratorFunc = @odeCFL2;
 case 'high'
  derivFunc = @upwindFirstENO3;
  integratorFunc = @odeCFL3;
 case 'veryHigh'
  derivFunc = @upwindFirstWENO5;
  integratorFunc = @odeCFL3;
 otherwise
  error('Unknown accuracy level %s', accuracy);
end

if(singleStep)
  integratorOptions = odeCFLset(integratorOptions, 'singleStep', 'on');
end

%---------------------------------------------------------------------------
% Set up basic motion in the normal direction.
normalFunc = @termNormal;
normalData.grid = g;
normalData.speed = 1;
normalData.derivFunc = derivFunc;

%---------------------------------------------------------------------------
% Set up curvature motion.
curvatureFunc = @termCurvature;
curvatureData.grid = g;
curvatureData.curvatureFunc = @curvatureSecond;
curvatureData.b = b;

%---------------------------------------------------------------------------
% Combine components of motion.
if(b > 0)
  % If there is a nonzero curvature contribution to speed.
  schemeFunc = @termSum;
  schemeData.innerFunc = { normalFunc; curvatureFunc };
  schemeData.innerData = { normalData; curvatureData };
else
  % Otherwise ignore curvature.
  schemeFunc = normalFunc;
  schemeData = normalData;
end


%---------------------------------------------------------------------------
% Set up data required for the mask operation.
%   Mask will be compared to vector form of data array used by integrator.
schemeData.mask = mask(:);
schemeData.doMask = doMask;

% Also keep track of minimum of phi over time.
%   Minimum will be kept in vector form used by integrator.
schemeData.min = data(:);
schemeData.doMin = doMin;

% Let the integrator know what function to call.
integratorOptions = odeCFLset(integratorOptions, ...
                              'postTimestep', @maskAndKeepMin);

%---------------------------------------------------------------------------
% Initialize Display
f = figure;

% Set up subplot parameters if necessary.
if(useSubplots)
  rows = ceil(sqrt(plotSteps));
  cols = ceil(plotSteps / rows);
  plotNum = 1;
  subplot(rows, cols, plotNum);
end

h = visualizeLevelSet(g, data, displayType, level, [ 't = ' num2str(t0) ]);

hold on;
if(g.dim > 1)
  axis(g.axis);
  daspect([ 1 1 1 ]);
end

%---------------------------------------------------------------------------
% Loop until tMax (subject to a little roundoff).
tNow = t0;
startTime = cputime;
while(tMax - tNow > small * tMax)

  % Reshape data array into column vector for ode solver call.
  y0 = data(:);

  % How far to step?
  tSpan = [ tNow, min(tMax, tNow + tPlot) ];
  
  % Take a timestep.
  %   Record returned schemeData structure to keep track of min over time.
  [ t y schemeData ] = feval(integratorFunc, schemeFunc, tSpan, y0,...
                             integratorOptions, schemeData);
  tNow = t(end);

  % Get back the correctly shaped data array
  data = reshape(y, g.shape);

  if(pauseAfterPlot)
    % Wait for last plot to be digested.
    pause;
  end

  % Get correct figure, and remember its current view.
  figure(f);
  figureView = view;

  % Delete last visualization if necessary.
  if(deleteLastPlot)
    delete(h);
  end

  % Move to next subplot if necessary.
  if(useSubplots)
    plotNum = plotNum + 1;
    subplot(rows, cols, plotNum);
  end

  % Create new visualization.
  h = visualizeLevelSet(g, data, displayType, level, [ 't = ' num2str(tNow) ]);
  %plotLevelSetInterior(data,level,mask)
  
  % Restore view.
  view(figureView);
  
end

%---------------------------------------------------------------------------
endTime = cputime;
fprintf('Total execution time %g seconds', endTime - startTime);


%---------------------------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%---------------------------------------------------------------------------
function [ yOut, schemeDataOut ] = maskAndKeepMin(t, yIn, schemeDataIn)
% maskAndKeepMin: Example postTimestep processing routine.
%
%  [ yOut, schemeDataOut ] = maskAndKeepMin(t, yIn, schemeDataIn)
%
%  This function demonstrates two entirely different processes that
%    can be accomplished through the postTimestep odeCFLn integrator option.
%
%  The first is to mask the evolving implicit surface function
%    (or otherwise modify its value after each timestep).
%
%  In this case masking is accomplished by
%
%          yOut = max(yIn, schemeDataIn.mask);
%
%
%   which ensures that phi cannot be negative anywhere that mask is positive.
%
%  The second is to keep track of some feature of that implicit surface
%    function or otherwise modify the schemeData structure after each
%    timestep.
%
%  In this case the feature recorded is the pointwise minimum over time of phi
%
%          schemeDataOut.min = min(yIn, schemeDataIn.min);
%
%
% Parameters:
%   t              Current time.
%   yIn            Input version of the level set function, in vector form.
%   schemeDataIn   Input version of a structure (see below).
%
%   yOut           Output version of the level set function, in vector form.
%   schemeDataOut  Output version of the structure (possibly modified).
%
% schemeData is a structure containing data specific to this type of 
%   term approximation.  For this function it contains the field(s)
%
%   .doMask      Boolean specifying whether masking should be performed.
%   .doMin       Boolean specifying whether min should be taken.
%   .mask	 Function against which to mask the level set function.
%   .min         Function which stores the minimum of the level set
%                  function over time (it is modified at each timestep).
%
% schemeData may contain other fields.

  checkStructureFields(schemeDataIn, 'doMask', 'doMin');

  % Mask the current level set function.
  if(schemeDataIn.doMask)
    checkStructureFields(schemeDataIn, 'mask');
    yOut = max(yIn, schemeDataIn.mask);
  else
    yOut = yIn;
  end

  % Record any new minimum values for each node.
  %   Use yOut to get the masked version of the data (if masking).
  schemeDataOut = schemeDataIn;
  if(schemeDataIn.doMin)
    checkStructureFields(schemeDataIn, 'min');
    schemeDataOut.min = min(yOut, schemeDataOut.min);
  end

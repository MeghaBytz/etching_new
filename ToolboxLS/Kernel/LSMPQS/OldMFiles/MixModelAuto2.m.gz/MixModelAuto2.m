function [ data, g, mask, curv] = MixModelAuto2(accuracy,b,tPlot,tMax,dxIn,GeomType,...
                                           OutFileName,ICplane,data0In,gIn,maskIn,a0)
%function [ data, g, mask, curv] = MixModelAuto(accuracy,tMax,dxIn,GeomType,...
%                                               OutFileName,ICplane,data0In,gIn,maskIn)
% Model tries to set pressure-like term (a) and curvature terms
% automatically and simulate drainage in the pore space
% phi_t(x,t) + a | grad phi(x,t)| = b kappa(phi) |grad phi(x,t)|
%
% phi - implicit function whose interior represents invading fluid
% _t  denotes temporal derivative
% grad denotes spatial gradient
% kappa denotes curvature

% a models pressure
% b is a constant that models surface tension btw invading and resident fluid

%  
% Parameters:
%
%   accuracy     Controls the order of approximations.
%                  'low'         Use odeCFL1 and upwindFirstFirst (default).
%                  'medium'      Use odeCFL2 and upwindFirstENO2.
%                  'high'        Use odeCFL3 and upwindFirstENO3.
%                  'veryHigh'    Use odeCFL3 and upwindFirstWENO5.
%   tMax         max simulation time, default 2.0
%   dxIn           grid spacing
%   GeomType     options 'Duct2D' (default), 'Sphere2D','Sphere3D','Poly2D'
%   OutFileName  name of the output file, default 'CapPressModel.out'
%   ICplane      Initial Condition plane - 'x' (for x=0 plane, default), 
%                'y' or 'z'

%   data         Implicit surface function at t_max.
%   g            Grid structure on which data was computed.
%   mask         Different pore space geometries are represented by some of 
%                the volume being masked (mask < 0 == pore space)
%  data0In, gIn, maskIn - 'data' array (level set function),grid and mask from
%                        a previous run (taken as initial conditions).

%---------------------------------------------------------------------------
% Make sure we can see the kernel m-files.
run('../addPathToKernel');
addpath ./InitCond ./MaskGrain ./Model ./Help

%---------------------------------------------------------------------------
% Which of the tasks do you wish to perform?
doMask = 1;
doMin = 0;

doOperSplit = 1;

[AvailGeom, MaskGeom] = SetAvailGeom;

%Sort out input variables
if( nargin < 1 )
    accuracy = 'medium';
end

if( nargin < 2 )
    b=0.1;
end

if( nargin < 3 )
    tPlot = 0.5;
end

if( nargin < 4 )
    tMax = 2.0;
end

if( nargin < 5 )
    dxIn = 0.04; % default grid spacing
end

if( nargin < 6 )
    GeomType = AvailGeom(1).type;
end;

if( nargin < 7) 
    OutFileName = 'MixModelAuto.out'; % output file for curvature results
    fprintf('Default output file is %s.',OutFileName);
end

if( nargin < 8 )
    ICplane = 'x'; % default initial condition is x=0 plane
elseif( (ICplane ~= 'x')&&(ICplane ~= 'y')&&(ICplane ~= 'z'))
    fprintf('Uknown initial condition plane specifier %s, reset to x (x=0)',ICplane);
    IClane = 'x';
end

testGeom = 0; [m n] = size(AvailGeom);
for i = 1:n
    if( strcmp(GeomType,AvailGeom(i).type) ) 
        testGeom = i;
    end
end

if (testGeom == 0)
    fprintf('Uknown geometry type %s, reset to %s',GeomType,AvailGeom(1).type);
    GeomType = AvailGeom(1).type;
    testGeom = 1;
end

factor = 1.0;

fid = fopen(OutFileName,'w');
fprintf(fid,'Time Start %s\n',datestr(now));
fprintf(fid,'Pore space fluid Level Set Method simulation\n');
fprintf(fid,'Geometry type = %s\n',GeomType);
fprintf(fid,'Initial condition = ''%s=0'' plane\n',ICplane);
fprintf(fid,'Accuracy = %s\n',accuracy);

fprintf(fid,'b = %g\n',b);
fprintf(fid,'f = %g (used in Step 1)\n',factor);


%---------------------------------------------------------------------------
% Integration parameters.
singleStep = 0;              % Plot at each timestep (overrides tPlot).

% Period at which intermediate plots should be produced.
%tPlot = (tMax - t0) / (plotSteps - 1);
%tPlot = 0.05; 
epsStop = 1e-3;

% How close (relative) do we need to get to tMax to be considered finished?
small = 100 * eps;

fprintf(fid,'Simulation continues until given tMax is reached\n'); 
fprintf(fid,'or max.abs.error for data(:,tFinal)-data(:,tFinal-%g)',tPlot);
fprintf(fid,'is less than epsStop.\n',tPlot);
fprintf(fid,'Simulation will also stop if max.abs.error starts increasing.\n');
fprintf(fid,'tMax = %g\n',tMax);
fprintf(fid,'epsStop = %g\n',epsStop);
fprintf(fid,'-------------------------------------------------------------\n');

%---------------------------------------------------------------------------
% What level set should we view?
level = 0;

%---------------------------------------------------------------------------
% Use periodic boundary conditions?
periodic = 0;

% if initial conditions, grid and mask are not provided then create them
if (nargin < 9)
    % Initialize grid dimensions.
    [data, data0, g] = InitializeDataGrid(mask,dxIn,testGeom,MaskGeom,ICplane,periodic);
else
    data0 = data0In;
    data  = data0In;
    g     = gIn;
    mask  = maskIn;
end

fprintf(fid,'Grid spacing  dx %g\n',g.dx(1));
fprintf(fid,'Volume limits [%g,%g]x[%g,%g]\n',g.min(1),g.max(1),g.min(2),g.max(2));

%---------------------------------------------------------------------------
% What kind of display?
switch(g.dim)
   case 1
    displayType = 'plot';
   case 2
    displayType = 'contour';    
   case 3
    displayType = 'surface';
   otherwise
    error('Default display type undefined for dimension %d', g.dim);
end

%---------------------------------------------------------------------------
% Set up time approximation scheme.
integratorOptions = odeCFLset('factorCFL', 0.5, 'stats', 'on');

% Choose approximations at appropriate level of accuracy.
%   Same accuracy is used by both components of motion.
switch(accuracy)
 case 'low'
  derivFunc = @upwindFirstFirst;
  integratorFunc = @odeCFL1;
 case 'medium'
  derivFunc = @upwindFirstENO2;
  integratorFunc = @odeCFL2;
 case 'high'
  derivFunc = @upwindFirstENO3;
  integratorFunc = @odeCFL3;
 case 'veryHigh'
  derivFunc = @upwindFirstWENO5;
  integratorFunc = @odeCFL3;
 otherwise
  error('Unknown accuracy level %s', accuracy);
end

if(singleStep)
  integratorOptions = odeCFLset(integratorOptions, 'singleStep', 'on');
end

% get initial volume of the invading fluid 
volume0 = size(find(data0 < 0 ));
volume0 = volume0(1);

% get max. possible volume of the invading fluid
%if( g.dim == 3 )
    volume_max = size(find(mask < 0 ));
    volume_max = volume_max(1)
%else
%   volume_max = areaLevelSetInterior(mask,g); % something ain't right for
%   sphere2D
%end

% Figure out entry condition
if( (ICplane == 'x') && (g.dim == 2))
    tmp = size(find(data0(1,:) < 0));
    tmp = tmp(1) *tmp(2); %initial slab of voxels on entry
elseif( (ICplane == 'y') && (g.dim == 2))
    tmp = size(find(data0(:,1) < 0));
    tmp = tmp(1) *tmp(2); %initial slab of voxels on entry    
else disp('Fix entry condition.');
end

Rt = 0.5 * tmp;
%volume_entry = 0.5 * (Rt*Rt*pi); % area of entry half-circle
%Vmax_frac = volume_entry / volume_max; %corresponding volume fraction
Vmax_frac = 1.0; %or maybe 0.8...

if (nargin < 12 ) %a0 not provided with input data    
    if( g.dim == 3) 
        a0 = b * (2/(Rt*g.dx(1))); %breakthrough pressure
    else
        a0 = b * (1/(Rt*g.dx(1))); %breakthrough pressure
    end
end

dc = 0.5 ; %curvature increment, note curvature = a/b
da = dc*b;
amax = 3*a0; %arbitrary as well; it's there so the run is limited

fprintf(fid,'\nEntry Rt %g, entry pressure a0 = b * (1/Rt) = %g',Rt*g.dx(1),a0);
fprintf(fid,'\nPressure increment da = %d\n',da);

if(g.dim == 2)
  % Display initial set, mask
  figure;
  lev = [ level level ];
  [ garbage, hI ] = contour(g.xs{1}, g.xs{2}, data0, lev,'b-');
  hold on;
  [ garbage, hM ] = contourf(g.xs{1}, g.xs{2}, mask, lev, 'k-');colormap gray;
  
  hs = [ hI; hM ];

  set(hs, 'LineWidth', 2.0);

  legend([ hI(1), hM(1) ], ...
         {'initial','mask'}, 2)
  axis equal
  axis(g.axis);
else
  warning('Cannot create final plot in dimensions other than 2D');
end

% save data for potential reuse
save data_init data0
save mask mask
save grid g

%---------------------------------------------------------------------------
% Set up curvature motion - since it doesn't change, set up only once.
curvatureFunc = @termCurvature;
curvatureData.grid = g;
curvatureData.curvatureFunc = @curvatureSecond;
curvatureData.b = b;

%Set normal term model - things that do not change
%--------------------------------------------------------------------------
normalFunc = @termNormal;
normalData.grid = g;
normalData.derivFunc = derivFunc;

%if( doOperSplit )
    % Also keep track of minimum of phi over time.
    %   Minimum will be kept in vector form used by integrator.
    normalData.min = data(:);
    normalData.doMin = doMin;
    normalData.mask = mask(:);
    normalData.doMask = doMask;
    
    curvatureData.min = data(:);
    curvatureData.doMin = doMin;
    curvatureData.mask = mask(:);
    curvatureData.doMask = doMask;
%else
    %---------------------------------------------------------------------------
    % Set up data required for the mask operation.
    %   Mask will be compared to vector form of data array used by integrator.
    schemeData.mask = mask(:);
    schemeData.doMask = doMask;

    % Also keep track of minimum of phi over time.
    %   Minimum will be kept in vector form used by integrator.
    schemeData.min = data(:);
    schemeData.doMin = doMin;
%end

% Let the integrator know what function to call.
integratorOptions = odeCFLset(integratorOptions, ...
                              'postTimestep', @maskAndKeepMin);

step = 1;
%store pressure for each step in aVal array
aVal(step) = a0;  

%if there's any initial data, skip step 1
if( data_in == 1) 
    fprintf(fid,'Step 1 skipped, data initialized from input data.');
    step = 2;
    a0 = a0 + da;
    aVal(step) = a0;
end
    
while( a0 <= amax )
    
    fprintf(fid,'\nStep %g',step);
    if (step == 1 ) fprintf(fid,'\na0 = %g, Vmax_frac %g\n',a0,Vmax_frac);
    else            fprintf(fid,'\na0 = %g\n',a0);
    end
    
    if(step == 1) % initalizing step 
        % Set compressible model for entry calculation (see
        % PressureModelMax() for more info
        % set normal term appropriately
        normalData.speed = @PressureModelVmax; % handle to the function that computes a(t)
        normalData.magnitude = a0;
        normalData.vmax = Vmax_frac*volume_max; % used in PressureModelVmax
        normalData.factor = factor;   % used in PressureModelVmax
    else
        % set normal term to constant
        normalData.speed = a0;
    end

    
    %---------------------------------------------------------------------------
    % Combine components of motion if we are not doing operator splitting
    %if (doOperSplit == 0 || step == 1)
        if(b > 0)
          % If there is a nonzero curvature contribution to speed.
          schemeFunc = @termSum;
          schemeData.innerFunc = { normalFunc; curvatureFunc };
          schemeData.innerData = { normalData; curvatureData };
        else
          % Otherwise ignore curvature.
          schemeFunc = normalFunc;
          schemeData = normalData;
        end
    %end

    %---------------------------------------------------------------------------
    % Loop until tMax (subject to a little roundoff) or max_abs_error is
    % satisfactory or max_abs_error starts increasing
    tNow = 0;
    startTime = cputime;
    max_abs_err = 1000.0;
    go_on = 1;
    num_tStep = 0;
   
    forward_flag = 0;
    
    while( go_on )
      if (step >= 2 ) fprintf(fid,'Forward step\n'); end
      % Reshape data array into column vector for ode solver call.
      y0 = data(:);

      % How far to step?
      tSpan = [ tNow, min(tMax, tNow + tPlot) ];

      %if( doOperSplit == 0 || step == 1 )
          % Take a timestep.
          %   Record returned schemeData structure to keep track of min over time.
          [ t y schemeData ] = feval(integratorFunc, schemeFunc, tSpan, y0,...
                                     integratorOptions, schemeData);
      %else
           % Take a timestep, but separate for each operator
           % Apply convective term in normal direction
       %    disp('advective');
        %   [ t y1 normalData ] = feval(integratorFunc, normalFunc, tSpan, y0,...
        %                             integratorOptions, normalData);
           % Apply curvature term in normal direction
         %  disp('curvature');
          % [ t y curvatureData ] = feval(integratorFunc, curvatureFunc, tSpan, y1,...
           %                  integratorOptions, curvatureData);     
      %end
      
      num_tStep = num_tStep + 1;
                             
      max_abs_err_old = max_abs_err;                           
      max_abs_err = max(abs(y - y0));
      fprintf('Time interval [%g,%g], max_abs error %g\n', tNow,t(end),max_abs_err);
      fprintf(fid,'Time interval [%g,%g], max_abs error %g\n', tNow,t(end),max_abs_err);
      tNow = t(end);

      % Get back the correctly shaped data array
      data = reshape(y,g.shape);
      data_old = reshape(y0,g.shape);
      
      if( step >=2 )
         %decide whether to proceed or no 
            tmp = size( find(data  < 0)); 
            vol(num_tStep) = tmp(1);
          
            if(num_tStep == 6) 
                    go_on = 0;
                    if ((vol(1) <= vol(4)) && (vol(4) <= vol(6)) ) 
                        forward_flag = 1;
                    else fprintf('vol1 %d vol4 %d vol6 %d',vol(1),vol(4),vol(6));
                    end   
            end
                %elseif( (num_tStep > 3) && (vol(num_tStep - 2) > vol(num_tStep - 1)) ...
            %                           && (vol(num_tStep - 1) > vol(num_tStep)) )
            %    fprintf(fid,'\nnum_tStep %d  later retreat detected vols %d > %d > %d',...
            %                   vol(num_tStep - 2),   vol(num_tStep - 1),  vol(num_tStep));
          
                   
      else
          forward_flag = 1;
      end
      
      non_empty = size( find (y > 0 ) ); non_empty = non_empty(1);

      if( step == 1) 
          go_on1 = (tMax - tNow > small * tMax) & (max_abs_err > epsStop) & (max_abs_err < max_abs_err_old) & non_empty;
          go_on = go_on & go_on1;
      end
      if(max_abs_err == max_abs_err_old)
          fprintf('tPlot=%g possibly too small, increase and rerun.',tPlot);
      end
      
      % I think this hit_end business works really only for throat/tube
      % geometry, for Sphere2d is strange for sure
      if( (ICplane == 'x' ) && (g.dim == 2) )
          hit_end = size( find(data(g.N(1),:) < 0) ); 
      elseif( (ICplane == 'y' ) && (g.dim == 2) )
          hit_end = size( find(data(:,g.N(2)) < 0) );
      else
          hit_end = [0 0];
          disp('Fix hit_end condition');
      end
      
      hit_end = hit_end(1)*hit_end(2);
      if (hit_end >= 2 )  %level set hit the opposite boundary
              go_on = 0;
              fprintf(fid,'\nLevel set hit the open boundary.');
              a0 = amax+1; % this effectively stops the iteration
      end
      
    end
    
    data1_is_set = 0;
    %backward stepping is done only for step 2 onward
    if( (step == 1) || (forward_flag == 0) || hit_end ) 
        go_on_back = 0;
        backward_flag = 1;
    else
        tNow = 0;
        max_abs_err = 1000.0;
        num_tStep = 0;
        
        go_on_back = 1;
        backward_flag = 0;
        data1 = data;  %work with the end of forward simulation
        %data1 = data0; %work with the beginning of forward simulation
    end
    
    %check weather the level set would retreat properly
    while( go_on_back )
      
      %a0_back = a0-1.5*da; this was for no operator splitting
      a0_back = a0-da;
      fprintf(fid,'Backward step -  applied pressure %g\n',a0_back);
      normalData.speed = a0_back;
      
      if( doOperSplit == 0 )
          schemeFunc = @termSum;
          schemeData.innerFunc = { normalFunc; curvatureFunc };
          schemeData.innerData = { normalData; curvatureData };
      end
      
      % Reshape data array into column vector for ode solver call.
      y0 = data1(:);  %work with an end of forward simulation

      % How far to step?
      tSpan = [ tNow, min(tMax, tNow + tPlot) ];

      if( doOperSplit == 0 || step == 1 )
          % Take a timestep.
          %   Record returned schemeData structure to keep track of min over time.
          [ t y schemeData ] = feval(integratorFunc, schemeFunc, tSpan, y0,...
                                     integratorOptions, schemeData);
      else
           % Take a timestep, but separate for each operator
           % Apply convective term in normal direction
           disp('advective');
           [ t y1 normalData ] = feval(integratorFunc, normalFunc, tSpan, y0,...
                             integratorOptions, normalData);
           % Apply curvature term in normal direction
           disp('curvature');
           [ t y curvatureData ] = feval(integratorFunc, curvatureFunc, tSpan, y1,...
                             integratorOptions, curvatureData);     
      end
      
      num_tStep = num_tStep + 1;
                             
      max_abs_err_old = max_abs_err;                           
      max_abs_err = max(abs(y - y0));
      fprintf('Time interval [%g,%g], max_abs error %g\n', tNow,t(end),max_abs_err);
      fprintf(fid,'Time interval [%g,%g], max_abs error %g\n', tNow,t(end),max_abs_err);
      tNow = t(end);

      % Get back the correctly shaped data1 array
      data1 = reshape(y,g.shape);
      data1_is_set = 1;
     
      tmp = size( find(data1  < 0)); 
      vol(num_tStep) = tmp(1); fprintf(fid,'num_tStep %d vol %d\n',num_tStep,vol(num_tStep));

      if ( (num_tStep == 3) && (vol(1) >= vol(2)) && (vol(2) >= vol(3)) ) 
        go_on_back = 0;  
        backward_flag = 1;
      end

      if(num_tStep == 3) 
            go_on_back = 0;
      end      
      
      non_empty = size( find (y > 0 ) ); non_empty = non_empty(1);

      %go_on_back1 = (tMax - tNow > small * tMax) & (max_abs_err > epsStop) &...
      %                              (max_abs_err < max_abs_err_old) & non_empty;
      %go_on_back = go_on_back & go_on_back1;
    end

    %---------------------------------------------------------------------------
    
    fprintf(fid,'\nforward_flag %d backward_flag %d',forward_flag,backward_flag);
    flag = forward_flag & backward_flag;
    
    endTime = cputime;
    fprintf('Execution time %g seconds', endTime - startTime);
    fprintf(fid,'Execution time %g seconds\n', endTime - startTime);
    
    if( flag )
        %max absolute error
         max_abs_err = max(max( abs(data - data_old)));
         fprintf(fid,'Max abs difference in  (data(:,%g) - data(:,%g)) everywhere\n',tNow,tNow-tPlot);
         fprintf(fid,'\t%g\n',max_abs_err);

         %output current volume of the fluid occupied part 
         volume = size(find(data < 0 ));
         volume = volume(1)
         fprintf(fid,'Invading fluid volume\n\tV(tMax) = %g, fraction total %g\n',volume,volume/volume_max);
         
         if( volume == volume_max ) % we invaded  entire available space 
            a0 = amax+1; % this will efectively stop iteration
         end      

         if (step == 1)
             fprintf(fid,'Maximal void space volume\n\tVolMax %g\n',volume_max);
             fprintf(fid,'Maximal volume in a(t) model\n\tVmax = %g\n',Vmax_frac*volume_max);
             %output current a
             rel_change = (volume - Vmax_frac*volume_max)/(Vmax_frac*volume_max);
             norm_speed =  a0 * exp(-factor*rel_change);
             fprintf(fid,'Normal speed\n\ta(tMax) = %g - ',norm_speed);
             a0 = norm_speed;
             fprintf(fid,'Pressure reset to normal_speed.\n');
             
         end
         
         fprintf(fid,'-------------------------------------------\n');
         if( g.dim == 2)
            if ( ceil(step/2) == step/2 )
                [ garbage, hF ] = contour(g.xs{1}, g.xs{2}, data, lev, 'r-'); hold on;
                %if( data1_is_set )
                %    [ garbage, hF ] = contour(g.xs{1}, g.xs{2}, data1, lev, 'm-'); hold on;
                %end
            else
                [ garbage, hF ] = contour(g.xs{1}, g.xs{2}, data, lev, 'g-'); hold on;
                %if( data1_is_set )
                %    [ garbage, hF ] = contour(g.xs{1}, g.xs{2}, data1, lev, 'c-'); hold on;
                %end
            end

            set(hF, 'LineWidth', 2.0);
            axis equal
            axis(g.axis);
         end
    else
        if ( ceil(step/2) == step/2 )
                [ garbage, hF ] = contour(g.xs{1}, g.xs{2}, data, lev, 'r-'); hold on;
                %if( data1_is_set )
                %    [ garbage, hF ] = contour(g.xs{1}, g.xs{2}, data1, lev, 'm-'); hold on;
                %end
            else
                [ garbage, hF ] = contour(g.xs{1}, g.xs{2}, data, lev, 'g-'); hold on;
                %if( data1_is_set ) 
                %    [ garbage, hF ] = contour(g.xs{1}, g.xs{2}, data1, lev, 'c-'); hold on;
                %end
            end
        fprintf(fid,'\nLevel set reached critical curvature.\n');
    end
    
    fname = sprintf('data_step%d',step);
    save(fname,'data');
         
    %compute current curvature
    if ( flag )    
        [curv grad_norm_data] = curvatureSecond(g,data);
        [k_avg k_min k_max] = displayCurvature(data,g,mask,curv,fid,0);
        fprintf(fid,'Curvature term\n\tb*k_avg = %g    b*k_max = %g\n',b*k_avg,b*k_max);
        
        data0 = data;
        a0 = a0 + da;
    
        step = step+1;
    else 
        a0 = amax + 1; %effectively stops iteration
    end
    
    
end

hold off;

disp('Memory usage after main loop'); whos
s = whos;
[n m]= size(s); mem=0;
for i=1:n, mem=mem+s(i).bytes; end
%fprintf('Total memory used (after main loop) %g bytes',mem);
fprintf(fid,'Total memory used (after main loop) %g bytes\n',mem);

%---------------------------------------------------------------------------
 
 
fprintf(fid,'Time End %s\n',datestr(now));
 
 fclose(fid);
% rmpath ./InitCond ./MaskGrain ./Model ./Help;
 
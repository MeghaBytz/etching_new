function [ data, g, mask, curv] = SplitNormCurvConst(accuracy,a,b,tMax,dxIn,GeomType,...
                                               OutFileName,ICplane,data0In,gIn,maskIn)
% CapPressModel : motion in normal direction and with a curvature term
%
% phi_t(x,t) + a(t)| grad phi(x,t)| = b kappa(phi) |grad phi(x,t)|
% phi - implicit function whose interior represents invading fluid
% _t  denotes temporal derivative
% grad denotes spatial gradient
% kappa denotes curvature
% a(t) is capillary pressure modeled as a(t) = exp(-f*(V(t)- Vmax)/Vmax) where V(t) is 
% volume of the invading fluid at time t, and Vmax the maximal volume the
% fluid could occupy
% f is an arbitary constant that is related to the volume of the invading
% fluid when the equation reaches the steady state

% b is a constant that models surface tension btw invading and resident fluid

% One can pass initial conditions that are final result of the
% previous run.
%  
% Edit the file to change the grid dimension, boundary conditions,
%   flow field parameters, etc.
%
% Parameters:
%
%   accuracy     Controls the order of approximations.
%                  'low'         Use odeCFL1 and upwindFirstFirst (default).
%                  'medium'      Use odeCFL2 and upwindFirstENO2.
%                  'high'        Use odeCFL3 and upwindFirstENO3.
%                  'veryHigh'    Use odeCFL3 and upwindFirstWENO5.
%   b            constant that models surface tension, default 2
%   factor       constant in the capillary pressure model a(t), default 3
%   tMax         max simulation time, default 2.0
%   dx           grid spacing
%   GeomType     options 'Duct2D' (default), 'Sphere2D','Sphere3D','Poly2D'
%   OutFileName  name of the output file, default 'CapPressModel.out'
%   ICplane      Initial Condition plane - 'x' (for x=0 plane), 'y' or 'z'
%                'circ' option WILL SET A CIRCULAR IC

%  
%   data         Implicit surface function at t_max.
%   g            Grid structure on which data was computed.
%   mask         Different geometries are represented by some of the volume being masked

%---------------------------------------------------------------------------
% Make sure we can see the kernel m-files.
run('../addPathToKernel');
addpath ./InitCond ./MaskGrain ./Model ./Help

%---------------------------------------------------------------------------
% Which of the tasks do you wish to perform?
doMask = 1;
doMin = 0;

[AvailGeom, MaskGeom] = SetAvailGeom;

%Sort out input variables
if( nargin < 1 )
    accuracy = 'medium';
end

if( nargin < 2 )
     aValue = 1.0; %default value
else aValue = a;
end

if( nargin < 3 )
    b = 1;  %default value
end

if( nargin < 4 )
    tMax = 2.0;
end

if( nargin < 5 )
    dxIn = 0.04; % default grid spacing
end

if( nargin < 6 )
    GeomType = AvailGeom(1).type;
end;

if( nargin < 7) 
    OutFileName = 'NormCurvConst.out'; % output file for curvature results
    fprintf('Default output file is %s.',OutFileName);
end

if( nargin < 8 )
    ICplane = 'x'; % default initial condition is x=0 plane
elseif( (ICplane ~= 'x')&&(ICplane ~= 'y')&&(ICplane ~= 'z') &&(ICplane ~= 'c'))
    fprintf('Uknown initial condition plane specifier %s, reset to x (x=0)',ICplane);
    ICplane = 'x';
end

testGeom = 0; [m n] = size(AvailGeom);
for i = 1:n
    if( strcmp(GeomType,AvailGeom(i).type) ) 
        testGeom = i;
    end
end

if (testGeom == 0)
    fprintf('Uknown geometry type %s, reset to %s',GeomType,AvailGeom(1).type);
    GeomType = AvailGeom(1).type;
    testGeom = 1;
end

fid = fopen(OutFileName,'w');
fprintf(fid,'Time Start %s\n',datestr(now));
fprintf(fid,'Capillary pressure Level Set Method simulation\n');
fprintf(fid,'Geometry type = %s\n',GeomType);
fprintf(fid,'Initial condition = ''%s=0'' plane\n',ICplane);
fprintf(fid,'Accuracy = %s\n',accuracy);
fprintf(fid,'a = %g\n', a);
fprintf(fid,'b = %g\n', b);

%---------------------------------------------------------------------------
% Integration parameters.
doPlot = 1;                  % Produce intermediate plots?
plotSteps = 9;               % How many intermediate plots to produce?
                             % if doPlot = 0, this can still be used to
                             % produce some other intermediate results
t0 = 0;                      % Start time.
singleStep = 0;              % Plot at each timestep (overrides tPlot).

% Period at which intermediate plots should be produced.
tPlot = (tMax - t0) / (plotSteps - 1);
%tPlot = 0.1; 
epsStop = 1e-3;

% How close (relative) do we need to get to tMax to be considered finished?
small = 100 * eps;

fprintf(fid,'Simulation continues until given tMax is reached\n'); 
fprintf(fid,'or max.abs.error for data(:,tFinal)-data(:,tFinal-%g)',tPlot);
fprintf(fid,'is less than epsStop.\n',tPlot);
fprintf(fid,'Simulation will also stop if max.abs.error starts increasing.');
fprintf(fid,'tMax = %g\n',tMax);
fprintf(fid,'epsStop = %g\n',epsStop);
fprintf(fid,'-------------------------------------------------------------\n');

%---------------------------------------------------------------------------
% What level set should we view?
level = 0;

% Pause after each plot?
pauseAfterPlot = 0;

% Delete previous plot before showing next?
deleteLastPlot = 0;

% Plot in separate subplots (set deleteLastPlot = 0 in this case)?
useSubplots = 1;

%---------------------------------------------------------------------------
% Use periodic boundary conditions?
periodic = 0;

% if initial conditions, grid and mask are not provided then create them
if (nargin < 9)
    % Initialize grid dimensions.
    [data, data0, g] = InitializeDataGrid(mask,dxIn,testGeom,MaskGeom,ICplane,periodic);
else
    data0 = data0In;
    data  = data0In;
    g     = gIn;
    mask  = maskIn;
end

fprintf(fid,'Grid spacing  dx %g\n',g.dx(1));
fprintf(fid,'Volume limits [%g,%g]x[%g,%g]\n',g.min(1),g.max(1),g.min(2),g.max(2));

%---------------------------------------------------------------------------
% What kind of display?
switch(g.dim)
   case 1
    displayType = 'plot';
   case 2
    displayType = 'contour';    
   case 3
    displayType = 'surface';
   otherwise
    error('Default display type undefined for dimension %d', g.dim);
end

%---------------------------------------------------------------------------
% Set up time approximation scheme.
integratorOptions = odeCFLset('factorCFL', 0.5, 'stats', 'on');

% Choose approximations at appropriate level of accuracy.
%   Same accuracy is used by both components of motion.
switch(accuracy)
 case 'low'
  derivFunc = @upwindFirstFirst;
  integratorFunc = @odeCFL1;
 case 'medium'
  derivFunc = @upwindFirstENO2;
  integratorFunc = @odeCFL2;
 case 'high'
  derivFunc = @upwindFirstENO3;
  integratorFunc = @odeCFL3;
 case 'veryHigh'
  derivFunc = @upwindFirstWENO5;
  integratorFunc = @odeCFL3;
 otherwise
  error('Unknown accuracy level %s', accuracy);
end

if(singleStep)
  integratorOptions = odeCFLset(integratorOptions, 'singleStep', 'on');
end

% get initial volume of the invading fluid 
volume0 = size(find(data0 < 0 ));
volume0 = volume0(1);

% get max. possible volume of the invading fluid
volume_max = size(find(mask < 0 ));
volume_max = volume_max(1)

%---------------------------------------------------------------------------
% Set up basic motion in the normal direction.
normalFunc = @termNormal;
normalData.grid = g;
normalData.speed = aValue;
normalData.derivFunc = derivFunc;

%---------------------------------------------------------------------------
% Set up curvature motion.
curvatureFunc = @termCurvature;
curvatureData.grid = g;
curvatureData.curvatureFunc = @curvatureSecond;
curvatureData.b = b;

%---------------------------------------------------------------------------
% Combine components of motion.
%if(b > 0)
%% If there is a nonzero curvature contribution to speed.
%  schemeFunc = @termSum;
%  schemeData.innerFunc = { normalFunc; curvatureFunc };
% schemeData.innerData = { normalData; curvatureData };
%else
%  % Otherwise ignore curvature.
%  schemeFunc = normalFunc;
%  schemeData = normalData;
%end


%---------------------------------------------------------------------------
% Set up data required for the mask operation.
%   Mask will be compared to vector form of data array used by integrator.
normalData.mask = mask(:);
normalData.doMask = doMask;
curvatureData.mask = mask(:);
curvatureData.doMask = doMask;

% Also keep track of minimum of phi over time.
%   Minimum will be kept in vector form used by integrator.
normalData.min = data(:);
normalData.doMin = doMin;
curvatureData.min = data(:);
curvatureData.doMin = doMin;

% Let the integrator know what function to call.
integratorOptions = odeCFLset(integratorOptions, ...
                              'postTimestep', @maskAndKeepMin);

if( doPlot)                         
    %---------------------------------------------------------------------------
    % Initialize Display
    f = figure;

    % Set up subplot parameters if necessary.
    if(useSubplots)
      rows = ceil(sqrt(plotSteps));
      cols = ceil(plotSteps / rows);
      plotNum = 1;
      subplot(rows, cols, plotNum);
    end

    h = visualizeLevelSet(g, data, displayType, level, [ 't = ' num2str(t0) ]);
    %plotLevelSetInterior(data,level,mask)

    hold on;
    if(g.dim > 1)
      axis(g.axis);
      daspect([ 1 1 1 ]);
    end
end

%---------------------------------------------------------------------------
% Loop until tMax (subject to a little roundoff) or max_abs_error is
% satisfactory or max_abs_error starts increasing
tNow = t0;
startTime = cputime;
max_abs_err = 1000.0;
go_on = 1;

while( go_on )
  
  % Reshape data array into column vector for ode solver call.
  y0 = data(:);

  % How far to step?
  tSpan = [ tNow, min(tMax, tNow + tPlot) ];
  
  % Take a timestep.
  % Apply convective term in normal direction
  [ t y1 normalData ] = feval(integratorFunc, normalFunc, tSpan, y0,...
                             integratorOptions, normalData);
  % Apply curvature term in normal direction
  [ t y curvatureData ] = feval(integratorFunc, curvatureFunc, tSpan, y1,...
                             integratorOptions, curvatureData);        
       
  
  max_abs_err_old = max_abs_err;                           
  max_abs_err = max(abs(y - y0));
  fprintf('Time interval [%g,%g], max_abs error %g\n', tNow,t(end),max_abs_err);
  fprintf(fid,'Time interval [%g,%g], max_abs error %g\n', tNow,t(end),max_abs_err);
  tNow = t(end);
  
  % Get back the correctly shaped data array
  data = reshape(y,g.shape);
  data_old = reshape(y0,g.shape);

  non_empty = size( find (y > 0 ) ); non_empty = non_empty(1);
  
  go_on = (tMax - tNow > small * tMax) & (max_abs_err > epsStop) & (max_abs_err < max_abs_err_old) & non_empty;
  if(max_abs_err == max_abs_err_old)
      fprintf('Possibly stuck with too small tPlot=%g, increase and rerun.',tPlot);
  end
  
  if( doPlot)
      if(pauseAfterPlot)
        % Wait for last plot to be digested.
        pause;
      end

      % Get correct figure, and remember its current view.
      figure(f);
      figureView = view;

      % Delete last visualization if necessary.
      if(deleteLastPlot)
        delete(h);
      end

      % Move to next subplot if necessary.
      if(useSubplots)
        plotNum = plotNum + 1;
        subplot(rows, cols, plotNum);
      end

      % Create new visualization.
      h = visualizeLevelSet(g, data, displayType, level, [ 't = ' num2str(tNow) ]);
      %plotLevelSetInterior(data,level,mask)

      % Restore view.
      view(figureView);
  end
end

%---------------------------------------------------------------------------
endTime = cputime;
fprintf('Total execution time %g seconds', endTime - startTime);
fprintf(fid,'Total execution time %g seconds\n', endTime - startTime);

disp('Memory usage after main loop'); whos
s = whos;
[n m]= size(s); mem=0;
for i=1:n, mem=mem+s(i).bytes; end
%fprintf('Total memory used (after main loop) %g bytes',mem);
fprintf(fid,'Total memory used (after main loop) %g bytes\n',mem);

%---------------------------------------------------------------------------


% Process and display final results.
%minOverTime = reshape(schemeData.min, g.shape);

if(g.dim == 2)
  % Display initial set, mask, minimum over time, and final set.
  figure;
  lev = [ level level ];
  [ garbage, hI ] = contour(g.xs{1}, g.xs{2}, data0, lev, 'b--');
  hold on;
  [ garbage, hF ] = contour(g.xs{1}, g.xs{2}, data, lev, 'r-');
  %[ garbage, hT ] = contour(g.xs{1}, g.xs{2}, minOverTime, lev, 'k:');
  [ garbage, hT ] = contour(g.xs{1}, g.xs{2}, data_old, lev, 'k:');
  [ garbage, hM ] = contourf(g.xs{1}, g.xs{2}, mask, lev, 'k-');colormap gray;
  %[ garbage, hM ] = contour(g.xs{1}, g.xs{2}, mask, lev, 'g-.');
  
  hs = [ hI; hF; hT; hM ];

  set(hs, 'LineWidth', 2.0);

  legend([ hI(1), hF(1), hT(1), hM(1) ], ...
         {'initial', 'final', 'plotStep before final', 'mask'}, 2);
         % {'initial', 'final', 'minOverTime', 'mask'}, 2);
  axis equal
  axis(g.axis);
else
  warning('Cannot create final plot in dimensions other than 2D');
end

 %compute current curvature
 [curv grad] = curvatureSecond(g, data);
 k_avg = displayCurvature(data,g,mask,curv,fid);
 
 %plot gradient
 plot_gradient2D(data0,g,mask);
 plot_gradient2D(data,g,mask);

 %max absolute error
 max_abs_err = max(max( abs(data - data_old)));
 fprintf(fid,'Max abs difference in  (data(:,%g) - data(:,%g)) everywhere\n',tNow,tNow-tPlot);
 fprintf(fid,'\t%g\n',max_abs_err);
  
 %output current volume of the fluid occupied part 
 volume = size(find(data < 0 ));
 volume = volume(1)
 fprintf(fid,'Invading fluid volume\n\tV(tMax) = %g, fraction total %g\n',volume,volume/volume_max);
 fprintf(fid,'Maximal void space volume\n\tVolMax %g\n',volume_max);
 
 fprintf(fid,'Time End %s\n',datestr(now));
 
 fclose(fid);
 rmpath ./InitCond ./MaskGrain ./Model ./Help;

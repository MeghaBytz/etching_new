function data  = LaplaceDuct(c,g,data,mask)

h = g.dx(1);  % has to be g.dx(1)=g.dx(2)!!!
n = g.N(1) - 1; % number of subintervals
m = g.N(2) - 1;

%BC - u=0 on top and sides of the square, u(x,0) = sin(pi*x)
%y_low = zeros(m+1,1);
%y_up  = zeros(m+1,1);
%x_low = zeros(n+1,1);
%x_up = zeros(n+1,1);


% Form problem Av=b

% b will be right hand side vector
N = (m-1)*(n-1)
%c is right hand side in the Laplace eqn
b = c*h*h*ones(N,1);    

a = ones(N,1);
A = -4*diag(a);

% incorporate BC in vector b and finish filling matrix A
% could have formed A by patching blocks
for(j=2:n)
   for(i=2:m)
        %compute appropriate index in b
        k = (m-1)*(j-2) + (i-1);
        %fprintf('i %d j %d k %d\n',i,j,k);
        
        if (i == 2)
            b(k) = b(k) - mask(i-1,j);
        else
            k1 = k - 1;
            A(k,k1) = 1;
        end 
        
        if (i == m)
            b(k) = b(k) - mask(i+1,j); 
        else
            k1 = k + 1;
            A(k,k1) = 1;
        end
        
        if (j == 2)
            b(k) = b(k) - mask(i,j-1); 
        else
            k1 = k - (m-1);
            A(k,k1) = 1;
        end 
        
        if (j == n)
            b(k) = b(k) - mask(i,j+1);
        else
            k1 = k + (m-1);
            A(k,k1) = 1;
        end
    end
end

%solve Av = b
[L U] = lu(A);
v = U\(L\b);

%plotting only interior points
v = reshape(v,m-1,n-1); 
%v = v'; % need to tranpose to get the plot of x & y right

%x = [h:h:(1-h)];
%y=  [h:h:(1-h)];
%[X Y] = meshgrid(x,y);
%plot3(X,Y,v)
mesh(v), xlabel('x'), ylabel('y')

data = mask;
data(2:n,2:m) = v;


function [ data, g, mask, curvature] = CapPressModel_y_ic(accuracy,b,f,tMax,GeomType,OutFileName,data0In,gIn,maskIn)
% CapPressModel : motion in normal direction and with a curvature term
%
% phi_t(x,t) + a(t)| grad phi(x,t)| = b kappa(phi) |grad phi(x,t)|
% phi - implicit function whose interior represents invading fluid
% _t  denotes temporal derivative
% grad denotes spatial gradient
% kappa denotes curvature
% a(t) is capillary pressure modeled as a(t) = exp(-f*(V(t)- Vmax)/Vmax) where V(t) is 
% volume of the invading fluid at time t, and Vmax the maximal volume the
% fluid could occupy
% f is an arbitary constant that is related to the volume of the invading
% fluid when the equation reaches the steady state

% b is a constant that models surface tension btw invading and resident fluid

% One can pass initial conditions that are final result of the
% previous run.
%  
% Edit the file to change the grid dimension, boundary conditions,
%   flow field parameters, etc.
%
% Parameters:
%
%   accuracy     Controls the order of approximations.
%                  'low'         Use odeCFL1 and upwindFirstFirst (default).
%                  'medium'      Use odeCFL2 and upwindFirstENO2.
%                  'high'        Use odeCFL3 and upwindFirstENO3.
%                  'veryHigh'    Use odeCFL3 and upwindFirstWENO5.
%   b            constant that models surface tension, default 2
%   f            constant in the capillary pressure model a(t), default 3
%   tMax         max simulation time, default 2.0
%   GeomType     options 'Duct2D' (default), 'Sphere2D','Sphere3D','Poly2D'
%   OutFileName  name of the output file, default 'CapPressModel.out'

%  
%   data         Implicit surface function at t_max.
%   g            Grid structure on which data was computed.
%   mask         Different geometries are represented by some of the volume being masked

%---------------------------------------------------------------------------
% Make sure we can see the kernel m-files.
run('../addPathToKernel');

%---------------------------------------------------------------------------
% Which of the tasks do you wish to perform?
doMask = 1;
doMin = 0;

AvailGeom = struct('type',{'Duct2D','Sphere2D','Sphere3D','Poly2D'});
MaskGeom  = struct('func',{@MaskDuct2D,@MaskSphere2D,@MaskSphere3D,@MaskPoly2D});

%Sort out input variables
if( nargin < 1 )
    accuracy = 'medium';
end

if( nargin < 2 )
    b = 2; %default value
end

if( nargin < 3 )
    f = 5;  %default value
end

if( nargin < 4 )
    tMax = 2.0;
end

if( nargin < 5 )
    GeomType = AvailGeom(1).type;
end;

if( nargin < 6) 
    OutFileName = 'CapPressModel.out'; % output file for curvature results
    fprintf('Default output file is %s.',OutFileName);
end

testGeom = 0; [m n] = size(AvailGeom);
for i = 1:n
    if( strcmp(GeomType,AvailGeom(i).type) ) 
        testGeom = i
    end
end

if (testGeom == 0)
    fprintf('Uknown geometry type %s, reset to %s',GeomType,AvailGeom(1).type);
    GeomType = AvailGeom(1).type;
    testGeom = 1;
end;

fid = fopen(OutFileName,'w'); 
fprintf(fid,'Capillary pressure Level Set Method simulation\n');
fprintf(fid,'Geometry type = %s\n',GeomType);
fprintf(fid,'Accuracy = %s\n',accuracy);
fprintf(fid,'b = %g\n', b);
fprintf(fid,'f = %g\n',f);

%---------------------------------------------------------------------------
% Integration parameters.
%tMax = 0.1;                 % End time; set as input variable
plotSteps = 6;               % How many intermediate plots to produce?
t0 = 0;                      % Start time.
singleStep = 0;              % Plot at each timestep (overrides tPlot).

% Period at which intermediate plots should be produced.
tPlot = (tMax - t0) / (plotSteps - 1);

% How close (relative) do we need to get to tMax to be considered finished?
small = 100 * eps;


fprintf(fid,'tMax = %g\n',tMax);
fprintf(fid,'-------------------------------------------------------------\n');

%---------------------------------------------------------------------------
% What level set should we view?
level = 0;

% Pause after each plot?
pauseAfterPlot = 0;

% Delete previous plot before showing next?
deleteLastPlot = 0;

% Plot in separate subplots (set deleteLastPlot = 0 in this case)?
useSubplots = 1;

%---------------------------------------------------------------------------
% Use periodic boundary conditions?
periodic = 0;


% if initial conditions, grid and mask are not provided then create them
if (nargin < 7)
    % Initialize grid dimensions.
    if( testGeom == 3) 
        g.dim = 3;
        g.min = 0;
    else
        g.dim = 2;
        g.min = -1;
    end
    nx = 50;
    g.dx = 1 / nx; 

    % create appropriate mask for 'Poly2D' geometry - need to read data
    % before grid is created
    if(testGeom == 4) [mask,g] = feval(MaskGeom(testGeom).func,g); end
    
    % Create grid
    if(periodic)
      g.max = (1 - g.dx);
      g.bdry = @addGhostPeriodic;
    else
      g.max = +1;
      g.bdry = @addGhostExtrapolate;
    end
    g = processGrid(g)
    
    % create appropriate mask
    if(testGeom < 4) [mask,g] = feval(MaskGeom(testGeom).func,g); end
        
    %----------------------------------------------------------------------
    % Create initial conditions
    data = CreateIC(g,'y');
   
    % Need to ensure that the initial conditions satisfy the mask.
    data = max(data, mask);

    data0 = data;
else
    data0 = data0In;
    data  = data0In;
    g     = gIn;
    mask  = maskIn;
end

if( (nargin == 8) || (nargin == 9) ) 
    error('Wrong number of input arguments.')
end

%---------------------------------------------------------------------------
% What kind of display?
switch(g.dim)
   case 1
    displayType = 'plot';
   case 2
    displayType = 'contour';    
   case 3
    displayType = 'surface';
   otherwise
    error('Default display type undefined for dimension %d', g.dim);
end

%---------------------------------------------------------------------------
% Set up time approximation scheme.
integratorOptions = odeCFLset('factorCFL', 0.5, 'stats', 'on');

% Choose approximations at appropriate level of accuracy.
%   Same accuracy is used by both components of motion.
switch(accuracy)
 case 'low'
  derivFunc = @upwindFirstFirst;
  integratorFunc = @odeCFL1;
 case 'medium'
  derivFunc = @upwindFirstENO2;
  integratorFunc = @odeCFL2;
 case 'high'
  derivFunc = @upwindFirstENO3;
  integratorFunc = @odeCFL3;
 case 'veryHigh'
  derivFunc = @upwindFirstWENO5;
  integratorFunc = @odeCFL3;
 otherwise
  error('Unknown accuracy level %s', accuracy);
end

if(singleStep)
  integratorOptions = odeCFLset(integratorOptions, 'singleStep', 'on');
end

% get initial volume of the invading fluid 
volume0 = size(find(data0 < 0 ));
volume0 = volume0(1);

% get max. possible volume of the invading fluid
volume_max = size(find(mask < 0 ));
volume_max = volume_max(1)

aValue = 1.0; % this variable doesn't mean much any more, vary f & b as needed
%---------------------------------------------------------------------------
% Set up basic motion in the normal direction.
normalFunc = @termNormal;
normalData.grid = g;
normalData.speed = @PressureModelVmax; % handle to the function that computes normal speed a(t)
normalData.magnitude = aValue;
normalData.derivFunc = derivFunc;
normalData.v0 = volume0;      % used in PressureModelVmax
normalData.vmax = volume_max; % used in PressureModelVmax
normalData.factor = f;        % used in PressureModelVmax

%---------------------------------------------------------------------------
% Set up curvature motion.
curvatureFunc = @termCurvature;
curvatureData.grid = g;
curvatureData.curvatureFunc = @curvatureSecond;
curvatureData.b = b;

%---------------------------------------------------------------------------
% Combine components of motion.
if(b > 0)
  % If there is a nonzero curvature contribution to speed.
  schemeFunc = @termSum;
  schemeData.innerFunc = { normalFunc; curvatureFunc };
  schemeData.innerData = { normalData; curvatureData };
else
  % Otherwise ignore curvature.
  schemeFunc = normalFunc;
  schemeData = normalData;
end

%delete structures that are not needed for memory efficiency
clear normalData;
clear curvatureData;

%---------------------------------------------------------------------------
% Set up data required for the mask operation.
%   Mask will be compared to vector form of data array used by integrator.
schemeData.mask = mask(:);
schemeData.doMask = doMask;

% Also keep track of minimum of phi over time.
%   Minimum will be kept in vector form used by integrator.
schemeData.min = data(:);
schemeData.doMin = doMin;

% Let the integrator know what function to call.
integratorOptions = odeCFLset(integratorOptions, ...
                              'postTimestep', @maskAndKeepMin);

%---------------------------------------------------------------------------
% Initialize Display
f = figure;

% Set up subplot parameters if necessary.
if(useSubplots)
  rows = ceil(sqrt(plotSteps));
  cols = ceil(plotSteps / rows);
  plotNum = 1;
  subplot(rows, cols, plotNum);
end

h = visualizeLevelSet(g, data, displayType, level, [ 't = ' num2str(t0) ]);
%plotLevelSetInterior(data,level,mask)

hold on;
if(g.dim > 1)
  axis(g.axis);
  daspect([ 1 1 1 ]);
end

%disp('Memory usage before main loop'); whos
%s = whos;
%[n m]= size(s); mem=0;
%for i=1:n, mem=mem+s(i).bytes; end
%fprintf('Total memory used (before main loop) %g bytes',mem);
%fprintf(fid,'Total memory used (before main loop) %g bytes\n',mem);

%---------------------------------------------------------------------------
% Loop until tMax (subject to a little roundoff).
tNow = t0;
startTime = cputime;
while(tMax - tNow > small * tMax)

  data_old = data;
  % Reshape data array into column vector for ode solver call.
  y0 = data(:);

  % How far to step?
  tSpan = [ tNow, min(tMax, tNow + tPlot) ];
  
  % Take a timestep.
  %   Record returned schemeData structure to keep track of min over time.
  [ t y schemeData ] = feval(integratorFunc, schemeFunc, tSpan, y0,...
                             integratorOptions, schemeData);
  tNow = t(end);

  % Get back the correctly shaped data array
  data = reshape(y,g.shape);

  if(pauseAfterPlot)
    % Wait for last plot to be digested.
    pause;
  end

  % Get correct figure, and remember its current view.
  figure(f);
  figureView = view;

  % Delete last visualization if necessary.
  if(deleteLastPlot)
    delete(h);
  end

  % Move to next subplot if necessary.
  if(useSubplots)
    plotNum = plotNum + 1;
    subplot(rows, cols, plotNum);
  end

  % Create new visualization.
  h = visualizeLevelSet(g, data, displayType, level, [ 't = ' num2str(tNow) ]);
  %plotLevelSetInterior(data,level,mask)

  % Restore view.
  view(figureView);
end

%---------------------------------------------------------------------------
endTime = cputime;
fprintf('Total execution time %g seconds', endTime - startTime);
fprintf(fid,'Total execution time %g seconds\n', endTime - startTime);

disp('Memory usage after main loop'); whos
s = whos;
[n m]= size(s); mem=0;
for i=1:n, mem=mem+s(i).bytes; end
%fprintf('Total memory used (after main loop) %g bytes',mem);
fprintf(fid,'Total memory used (after main loop) %g bytes\n',mem);

%---------------------------------------------------------------------------
% Process and display final results.
minOverTime = reshape(schemeData.min, g.shape);

if(g.dim == 2)
  % Display initial set, mask, minimum over time, and final set.
  figure;
  lev = [ level level ];
  [ garbage, hI ] = contour(g.xs{1}, g.xs{2}, data0, lev, 'b--');
  hold on;
  [ garbage, hF ] = contour(g.xs{1}, g.xs{2}, data, lev, 'r-');
  %[ garbage, hT ] = contour(g.xs{1}, g.xs{2}, minOverTime, lev, 'k:');
  [ garbage, hT ] = contour(g.xs{1}, g.xs{2}, data_old, lev, 'k:');
  [ garbage, hM ] = contour(g.xs{1}, g.xs{2}, mask, lev, 'g-.');
  
  hs = [ hI; hF; hT; hM ];

  set(hs, 'LineWidth', 2.0);

  legend([ hI(1), hF(1), hT(1), hM(1) ], ...
         {'initial', 'final', 'plotStep before final', 'mask'}, 2);
         % {'initial', 'final', 'minOverTime', 'mask'}, 2);
  axis equal
  axis(g.axis);
else
  warning('Cannot create final plot in dimensions other than 2D');
end

%compute current curvature
 curvature = curvatureSecond(g, data);
 front = find( abs(data) < 0.001);
 k_avg = mean( curvature(front) )
 k_min =  min( curvature(front) )
 k_max =  max( curvature(front) )
 
 %max error on the front
 max_abs_error = max( abs( data(front) - data_old(front)));
 fprintf(fid,'\nMax abs error in (data(:,%g) - data(:,%g))\n',tMax,tMax-tPlot);
 fprintf(fid,'on the front (abs(data) < 0.001)\n');
 fprintf(fid,'\t%g\n',max_abs_error);
 
 max_abs_error = max(max( abs(data - data_old)));
 fprintf(fid,'Max abs error in  (data(:,%g) - data(:,%g)) everywhere\n',tMax,tMax-tPlot);
 fprintf(fid,'\t%g\n',max_abs_error);
 
 %nonzero curvature
 front_nonzero = find(( abs(data) < 0.001) & (curvature > 0.01));
 k_avg_nonzero = mean( curvature(front_nonzero) )
 
 %curvature on fluid-fluid intfc (avoid fluid/grain space intfc)
 front_fld_intfc = find(( abs(data) < 0.001) & (abs(mask) > 0.001));
 k_avg_fld_intfc = mean( curvature(front_nonzero) )

 fprintf(fid,'\nCurvature on the front (abs(data) < 0.001)\n');
 fprintf(fid,'\tk_avg = %g\n\tk_min = %g\n\tk_max = %g\n',k_avg,k_min,k_max);
 fprintf(fid,'Nonzero curvature ((abs(data) < 0.001) & (curvature > 0.01)\n');
 fprintf(fid,'\tk_avg_nonzero = %g\n',k_avg_nonzero);
 fprintf(fid,'Fluid intfc ((abs(data) < 0.001) & (abs(mask) > 0.001)\n');
 fprintf(fid,'\tk_avg_fld_intfc %g\n',k_avg_fld_intfc);
 
 if(g.dim == 2)
     %plot curvature
     [I,J] = find( abs(data) < 0.001);
     K = curvature(front);
     figure,plot3(I,J,K,'.'),xlabel('x'), ylabel('y'), zlabel('curvature')
 end
 
 %output current volume of the fluid occupied part 
 volume = size(find(data < 0 ));
 volume = volume(1)
 fprintf(fid,'Invading fluid volume\n\tV(tMax) = %g\n',volume);
 fprintf(fid,'Maximal void space volume\n\tVmax = %g\n',volume_max);
 
 %output current a
 rel_change = (volume - volume_max)/volume_max;
 factor = 3;
 norm_speed =  aValue * exp(-factor*rel_change);
 fprintf(fid,'Normal speed\n\ta(tMax) = %g\n',norm_speed);
 fprintf(fid,'\tb*k_avg_nonzero = %g\n',b*k_avg_nonzero);
 
 fclose(fid);
 


 
function [mask,g] = MaskDuct2D(g)
%--------------------------------------------------------------------------
% Create mask (intersection of hyperplanes creates a horizontal duct)
%--------------------------------------------------------------------------
    n = 2; % number of hyperplanes

    normal = [ 0.0; -1.0];
    point = zeros(g.dim,1);
    point(2) = -1.0 + g.dx(1); % g.min(1) is -1.0
    mask = shapeHyperplane(g,normal,point);

    normal = [ 0.0; 1.0];
    point = zeros(g.dim,1);
    point(2) = 1.0 - g.dx(1); % g.max(1) is 1.0

    mask = max(mask,shapeHyperplane(g,normal,point));
    
    
function [mask,g] = MaskPoly2D(g)
%--------------------------------------------------------------------------
% Create mask by reading in a signed distance function (3dma l2 burn file 
% format
%--------------------------------------------------------------------------
    fid = fopen('pore_slice_sgn_dist_fun','r');
    e  = fread(fid,1,'char');
    nx = fread(fid,1,'int');
    ny = fread(fid,1,'int'); 
    zs = fread(fid,1,'int');
    ze = fread(fid,1,'int');

    % we assume nx = ny and zs=ze, i.e. 2D data 
    n = nx;
    mask1 = fread(fid,[n n],'single');
    fclose(fid);

    % Grid dimensions determined by the rasterfile size
    g.dim = 2;
    g.min = 0;
    g.dx = 1 / (n-1);
    
    mask = mask1;
    
function  [mask,g] = MaskSphere2D(g)
%--------------------------------------------------------------------------
% Create mask that corresponds to void space btw 3 equal spheres
%--------------------------------------------------------------------------
    n = 3;  % number of masking spheres

    maskCenter(:,1) = [-1.0; 2.2; 0.0; 0.0 ];
    maskRadius(1) = 2.0;

    maskCenter(:,2) = [-1.0; -2.2; 0.0; 0.0 ];
    maskRadius(2) = 2.0;

    maskCenter(:,3) = [2.5; 0.0; 0.0; 0.0 ];
    maskRadius(3) = 2.0;

    % The moving set can be anywhere outside the masked region.
    %  '-' sign is to get the complement of the masked region.
    mask = - shapeSphere(g, maskCenter(:,1), maskRadius(1));
    for i=2:n
       mask = max(mask,-shapeSphere(g, maskCenter(:,i), maskRadius(i)));
    end
   
function [mask,g] = MaskSphere3D    
%---------------------------------------------------------------------------
% Create mask (void space btw 4 spheres and 3 hyperplanes)
%---------------------------------------------------------------------------
r = 1;  % sphere radius
n = 4;  % number of masking spheres

% 4 spheres of radius r have centers at columns of maskCenter
a = 2*r;
v = a*sqrt(3)/2.0;
k = a *sqrt(2.0/3.0);
maskCenter = [0 0 0; a 0 0; a/2 v 0; a/2 v/3 k];
maskCenter = maskCenter';

% The moving set can be anywhere outside the masked region.
%  '-' sign is to get the complement of the masked region.
mask = - shapeSphere(g, maskCenter(:,1), r);
%figure, visualizeLevelSet(g, mask, displayType, level, [ 't = ' num2str(t0) ]);

for i=2:n
  mask = max(mask,-shapeSphere(g, maskCenter(:,i),r));
   %figure, visualizeLevelSet(g, mask, displayType, level, [ 't = ' num2str(t0) ]);
end

point0 = maskCenter(:,4);
for i=1:(n-1)
   point1 = maskCenter(:,i);
   if ( i == 3) point2 = maskCenter(:,1);
   else point2 = maskCenter(:,i+1);
   end
   
   A = point1 - point0;
   B = point2 - point0;
   normal = cross(A,B);
   normal = normal/norm(normal);
   
   mask = max(mask,shapeHyperplane(g,normal,point0));
end

function data = CreateIC(g,plane)
%--------------------------------------------------------------------------
% Create initial conditions
% g - grid
% plane - 'x' (plane x=0), 'y' (plane y=0) or 'z' (plane z = 0)
%--------------------------------------------------------------------------
    if( g.dim == 2 )
        % in 2D hyperplane x=0 at (g.min+g.dx,0,0).
        if( plane == 'x')
            normal = [ 1.0; 0.0];
            point  = [g.min(1) + g.dx(1);0.0];
        else
            normal = [0.0;1.0];
            point  = [0.0;g.min(2) + g.dx(1)];
        end     
    else
        if( plane == 'z')
            normal = [0.0; 0.0; 1.0];
            point  = [0.0; 0.0;g.min(3)+g.dx(3)];
        elseif( plane == 'y')
            normal = [0.0; 1.0;0.0];
            point  = [0.0;g.min(2)+g.dx(2);0.0];
        else
            normal = [1.0; 0.0; 0.0];
            point  = [g.min(1)+g.dx(1);0.0;0.0];
        end
    end
    data = shapeHyperplane(g,normal,point); 
    

%--------------------------------------------------------------------------
%  Model for varying velocity in normal direction
%--------------------------------------------------------------------------
function new_a = PressureModelVmax(t,data,schemeData)
    %% current volume occupied by invading fluid
    volume = size(find(data < 0));
    volume = volume(1);
    % relative change in volume - this didn't work
    % rel_change = (volume - schemeData.v0)/schemeData.v0;
    % change relative to the max. possible volume
    vmax = schemeData.vmax;
    rel_change = (volume - vmax)/vmax;
    factor = schemeData.factor;  % arbitrary, set beforehand
    new_a = schemeData.magnitude * exp(-factor*rel_change);
    schemeData.v0 = volume;

%---------------------------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%---------------------------------------------------------------------------
function [ yOut, schemeDataOut ] = maskAndKeepMin(t, yIn, schemeDataIn)
% maskAndKeepMin: Example postTimestep processing routine.
%
%  [ yOut, schemeDataOut ] = maskAndKeepMin(t, yIn, schemeDataIn)
%
%  This function demonstrates two entirely different processes that
%    can be accomplished through the postTimestep odeCFLn integrator option.
%
%  The first is to mask the evolving implicit surface function
%    (or otherwise modify its value after each timestep).
%
%  In this case masking is accomplished by
%
%          yOut = max(yIn, schemeDataIn.mask);
%
%
%   which ensures that phi cannot be negative anywhere that mask is positive.
%
%  The second is to keep track of some feature of that implicit surface
%    function or otherwise modify the schemeData structure after each
%    timestep.
%
%  In this case the feature recorded is the pointwise minimum over time of phi
%
%          schemeDataOut.min = min(yIn, schemeDataIn.min);
%
%
% Parameters:
%   t              Current time.
%   yIn            Input version of the level set function, in vector form.
%   schemeDataIn   Input version of a structure (see below).
%
%   yOut           Output version of the level set function, in vector form.
%   schemeDataOut  Output version of the structure (possibly modified).
%
% schemeData is a structure containing data specific to this type of 
%   term approximation.  For this function it contains the field(s)
%
%   .doMask      Boolean specifying whether masking should be performed.
%   .doMin       Boolean specifying whether min should be taken.
%   .mask	 Function against which to mask the level set function.
%   .min         Function which stores the minimum of the level set
%                  function over time (it is modified at each timestep).
%
% schemeData may contain other fields.

  checkStructureFields(schemeDataIn, 'doMask', 'doMin');

  % Mask the current level set function.
  if(schemeDataIn.doMask)
    checkStructureFields(schemeDataIn, 'mask');
    yOut = max(yIn, schemeDataIn.mask);
  else
    yOut = yIn;
  end

  % Record any new minimum values for each node.
  %   Use yOut to get the masked version of the data (if masking).
  schemeDataOut = schemeDataIn;
  if(schemeDataIn.doMin)
    checkStructureFields(schemeDataIn, 'min');
    schemeDataOut.min = min(yOut, schemeDataOut.min);
  end

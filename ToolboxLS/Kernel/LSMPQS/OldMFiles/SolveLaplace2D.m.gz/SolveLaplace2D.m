function [ data, g, mask, curvature] = SolveLaplace2D(c,GeomType,OutFileName)
% SolveLaplace: phi_xx + phi_yy = c
%               |grad phi| = 1 (renormalization)
%
% phi - implicit function whose interior represents invading fluid
% grad denotes spatial gradient
% 
% Parameters:
%
%   c           a constant that models capillary pressure divided by surface tension
%                btw fluids
%   GeomType     options 'Duct2D' (default), 'Sphere2D','Sphere3D','Poly2D'
%   OutFileName  name of the output file, default 'CapPressModel.out'
%  
%   data         Implicit surface function
%   g            Grid structure on which data was computed.
%   mask         Different geometries are represented by some of the volume being masked


%---------------------------------------------------------------------------
% Make sure we can see the kernel m-files.
run('../addPathToKernel');

%---------------------------------------------------------------------------

AvailGeom = struct('type',{'Duct2D','Sphere2D','Sphere3D','Poly2D'});
MaskGeom  = struct('func',{@MaskDuct2D,@MaskSphere2D,@MaskSphere3D,@MaskPoly2D});

%Sort out input variables
if( nargin < 1 )
    c = 1; %default value
end

if( nargin < 2 )
    GeomType = AvailGeom(1).type;
end;

if( nargin < 3) 
    OutFileName = 'SolveLaplace.out'; % output file for curvature results
    fprintf('Default output file is %s.',OutFileName);
end

testGeom = 0; [m n] = size(AvailGeom);
for i = 1:n
    if( strcmp(GeomType,AvailGeom(i).type) ) 
        testGeom = i;
    end
end

if (testGeom == 0)
    fprintf('Uknown geometry type %s, reset to %s',GeomType,AvailGeom(1).type);
    GeomType = AvailGeom(1).type;
    testGeom = 1;
elseif(testGeom == 3)
    fprintf('3D solutions currently not supported.');
end

fid = fopen(OutFileName,'w'); 
fprintf(fid,'Laplace Equation solver\n');
fprintf(fid,'Geometry type = %s\n',GeomType);
fprintf(fid,'c = %g\n', c);

fprintf(fid,'-------------------------------------------------------------\n');

%---------------------------------------------------------------------------
% What level set should we view?
level = 0;

% if initial conditions, grid and mask are not provided then create them

% Initialize grid dimensions.
nx = 25;
g.dx = 1 / nx;

if( testGeom == 3) 
    g.dim = 3;
    g.min = 0;
else
    g.dim = 2;
    g.min = -1;
end

% create appropriate mask for 'Poly2D' geometry - need to read data
% before grid is created
if(testGeom == 4) [mask,g] = feval(MaskGeom(testGeom).func,g); end

% Create grid
g.max = +1;
g.bdry = @addGhostExtrapolate;
g = processGrid(g)
dim = [1;2];
fprintf(fid,'Grid spacing in dim. %d = %g\n',dim,g.dx);

% create appropriate mask that defines our avaialable void space
if(testGeom < 4) [mask,g] = feval(MaskGeom(testGeom).func,g); end

% Mask is effectively a grain boundary condition.
% Incorporate void boundary conditions in the mask
% for now, this works for duct
B = g.N(1)/2;

%for( i=1:g.N(1) ) 
 %   if( mask(i,1) < 0 ),      mask(i,1)      = -mask(i,1); end
    %if( mask(i,g.N(1)) < 0 ), mask(i,g.N(1)) = - mask(i,g.N(1)) ; end
%end

for( i=1:g.N(2) ) 
 if( mask(1,i) < 0 ),      mask(1,i)      = -B; end
 if( mask(g.N(2),i) < 0 ), mask(g.N(1),i) =  i/2; end
end

%---------------------------------------------------------------------------
% What kind of display?
switch(g.dim)
   case 1
    displayType = 'plot';
   case 2
    displayType = 'contour';    
   case 3
    displayType = 'surface';
   otherwise
    error('Default display type undefined for dimension %d', g.dim);
end

startTime = cputime;

%---------form algebraic equations-----------%
%This works for duct right now.
data0 = LaplaceDuct(c,g,mask);

%data = reinitialize(data0,g,'medium');
data = data0;

%---------------------------------------------------------------------------
endTime = cputime;
fprintf('Total execution time %g seconds', endTime - startTime);
fprintf(fid,'Total execution time %g seconds\n', endTime - startTime);

disp('Memory usage after main loop'); whos
s = whos;
[n m]= size(s); mem=0;
for i=1:n, mem=mem+s(i).bytes; end
%fprintf('Total memory used (after main loop) %g bytes',mem);
fprintf(fid,'Total memory used (after main loop) %g bytes\n',mem);

%---------------------------------------------------------------------------


 % Process and display final results.

if(g.dim == 2)
  % Display mask and final set.
  figure;
  lev = [ level level ];
 
  [ garbage, hF ] = contour(g.xs{1}, g.xs{2}, data, lev, 'r-'); hold on;
  [ garbage, hM ] = contour(g.xs{1}, g.xs{2}, mask, lev, 'g-.');
  
  hs = [ hF; hM ];

  set(hs, 'LineWidth', 2.0);

  legend([ hF(1), hM(1) ], ...
         {'final','mask'}, 2);
  axis equal
  axis(g.axis);
else
  warning('Cannot create final plot in dimensions other than 2D');
end

 %compute current curvature
 eps_front = 0.01;
 curvature = curvatureSecond(g, data);
 front = find( abs(data) < eps_front);
 k_avg = mean( curvature(front) )
 k_min =  min( curvature(front) )
 k_max =  max( curvature(front) )

 
 %curvature on fluid-fluid intfc (avoid fluid/grain space intfc)
 eps_mask = -g.dx(1); 
 front_fld_intfc = find(( abs(data) < eps_front) & (mask < eps_mask));
 k_avg_fld_intfc = mean( curvature(front_fld_intfc) )
 k_min_fld_intfc = min( curvature(front_fld_intfc) )
 k_max_fld_intfc = max( curvature(front_fld_intfc) )

 fprintf(fid,'\nFront curvature (abs(data) < %g)\n',eps_front);
 fprintf(fid,'\tk_avg = %g\n\tk_min = %g\n\tk_max = %g\n',k_avg,k_min,k_max);
 fprintf(fid,'Fluid interface curvature ((abs(data) < %g) & (mask < %g)\n', eps_front,eps_mask);
 fprintf(fid,'\tk_avg_fld_intfc %g\n',k_avg_fld_intfc);
 fprintf(fid,'\tk_min_fld_intfc %g\n',k_min_fld_intfc);
 fprintf(fid,'\tk_max_fld_intfc %g\n',k_max_fld_intfc);
 
 if(g.dim == 2)
     %plot curvature
     [I,J] = find(( abs(data) < eps_front) & (mask < eps_mask));
     K = curvature(front_fld_intfc);
     figure,plot3(I,J,K,'.'),xlabel('x'), ylabel('y'), zlabel('fld intfc curvature')
     axis([0 g.N(1) 0 g.N(2) k_min_fld_intfc k_max_fld_intfc])
 end
 
 %output current volume of the fluid occupied part 
 volume = size(find(data < 0 ));
 volume = volume(1)
 fprintf(fid,'Invading fluid volume\n\tV(tMax) = %g\n',volume);
 %fprintf(fid,'Maximal void space volume\n\tVmax = %g\n',volume_max); 
 
fclose(fid);
 

 
function [mask,g] = MaskDuct2D(g)
%--------------------------------------------------------------------------
% Create mask (intersection of hyperplanes creates a horizontal duct)
%--------------------------------------------------------------------------
    normal = [ 0.0; -1.0];
    point  = [0;g.min(2) + g.dx(2)];
    mask = shapeHyperplane(g,normal,point);

    normal = [ 0.0; 1.0];
    point  = [0;g.max(2) - g.dx(2)];

    mask = max(mask,shapeHyperplane(g,normal,point));
    
    
function [mask,g] = MaskPoly2D(g)
%--------------------------------------------------------------------------
% Create mask by reading in a signed distance function (3dma l2 burn file 
% format
%--------------------------------------------------------------------------
    fid = fopen('pore_slice_sgn_dist_fun','r');
    e  = fread(fid,1,'char');
    nx = fread(fid,1,'int');
    ny = fread(fid,1,'int'); 
    zs = fread(fid,1,'int');
    ze = fread(fid,1,'int');

    % we assume nx = ny and zs=ze, i.e. 2D data 
    n = nx;
    mask1 = fread(fid,[n n],'single');
    fclose(fid);

    % Grid dimensions determined by the rasterfile size
    g.dim = 2;
    g.min = 0;
    g.dx = 1 / (n-1);
    
    mask = mask1;
    
function  [mask,g] = MaskSphere2D(g)
%--------------------------------------------------------------------------
% Create mask that corresponds to void space btw 3 equal spheres
%--------------------------------------------------------------------------
    n = 3;  % number of masking spheres

    maskCenter(:,1) = [-1.0; 2.2; 0.0; 0.0 ];
    maskRadius(1) = 2.0;

    maskCenter(:,2) = [-1.0; -2.2; 0.0; 0.0 ];
    maskRadius(2) = 2.0;

    maskCenter(:,3) = [2.5; 0.0; 0.0; 0.0 ];
    maskRadius(3) = 2.0;

    % The moving set can be anywhere outside the masked region.
    %  '-' sign is to get the complement of the masked region.
    mask = - shapeSphere(g, maskCenter(:,1), maskRadius(1));
    for i=2:n
       mask = max(mask,-shapeSphere(g, maskCenter(:,i), maskRadius(i)));
    end
   
function [mask,g] = MaskSphere3D    
%---------------------------------------------------------------------------
% Create mask (void space btw 4 spheres and 3 hyperplanes)
%---------------------------------------------------------------------------
r = 1;  % sphere radius
n = 4;  % number of masking spheres

% 4 spheres of radius r have centers at columns of maskCenter
a = 2*r;
v = a*sqrt(3)/2.0;
k = a *sqrt(2.0/3.0);
maskCenter = [0 0 0; a 0 0; a/2 v 0; a/2 v/3 k];
maskCenter = maskCenter';

% The moving set can be anywhere outside the masked region.
%  '-' sign is to get the complement of the masked region.
mask = - shapeSphere(g, maskCenter(:,1), r);
%figure, visualizeLevelSet(g, mask, displayType, level, [ 't = ' num2str(t0) ]);

for i=2:n
  mask = max(mask,-shapeSphere(g, maskCenter(:,i),r));
   %figure, visualizeLevelSet(g, mask, displayType, level, [ 't = ' num2str(t0) ]);
end

point0 = maskCenter(:,4);
for i=1:(n-1)
   point1 = maskCenter(:,i);
   if ( i == 3) point2 = maskCenter(:,1);
   else point2 = maskCenter(:,i+1);
   end
   
   A = point1 - point0;
   B = point2 - point0;
   normal = cross(A,B);
   normal = normal/norm(normal);
   
   mask = max(mask,shapeHyperplane(g,normal,point0));
end    

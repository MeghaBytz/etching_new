function display_curvature_new(data,g,mask,curvature,OutFile)

%compute current curvature
 C = countourc(data,[0 0]); % find a 0-level set and output coords to matrix C
 Cmask = countourc(mask,[0 0]);
 
 n = C(2,1); m = Cmask(2,1); % number of points on each level set
 % get the coordinates
 x = C(1,2:(n+1)); x = x';
 y = C(2,2:(n+1)); y = y';
 %find interpolated curvature values at these coords
 %curv_interp = interp2(data,x,y);
 
 l = floor(x); t = x - floor(x); t1 = ones(n)-t;
 k = floor(y); s = y - floor(y); s1 = ones(n)-s;
 lup = l + ones(n);
 lup = min(lup,N*ones(n));
 kup = k + ones(n);
 kup = min(kup,M*ones(n));
 
 [M N] = size(data);
 z = curvature;
 for(i=1:n)
     zinterp(i)= t1(i)*s1(i)*data(l(i),k(i)) + t(i)*s1(i)* data(lup(i),k(i))+...
                 t1(i)*s(i)*data(l(i),kup(i)) + t(i)*s(i)*data(lup(i),kup(i))
 end
 
 
 
 front = find(data > 0); size(front)
 pos_min = min(min(data(front)))
 
 front = find(data < 0); size(front)
 neg_max = max(max(data(front)))
 
 front_fld_intfc = find(data >=3*neg_max & data <= 3*pos_min);
 size( front_fld_intfc)
 
 %k_avg = mean( curvature(front) )
 %k_min =  min( curvature(front) )
 %k_max =  max( curvature(front) )

 %curvature on fluid-fluid intfc (avoid fluid/grain space intfc)
 %eps_mask = -g.dx(1);

 k_avg_fld_intfc = mean( curvature(front_fld_intfc) )
 k_min_fld_intfc = min( curvature(front_fld_intfc) )
 k_max_fld_intfc = max( curvature(front_fld_intfc) )

 if (nargin >= 6)
     fid = fopen(OutFile,'w');
     fprintf(fid,'\nFront curvature (abs(data) < %g)\n',eps_front);
     fprintf(fid,'\tk_avg = %g\n\tk_min = %g\n\tk_max = %g\n',k_avg,k_min,k_max);
     fprintf(fid,'Fluid interface curvature ((abs(data) < %g) & (mask < %g)\n', eps_front,eps_mask);
     fprintf(fid,'\tk_avg_fld_intfc %g\n',k_avg_fld_intfc);
     fprintf(fid,'\tk_min_fld_intfc %g\n',k_min_fld_intfc);
     fprintf(fid,'\tk_max_fld_intfc %g\n',k_max_fld_intfc);
 end
 
 if(g.dim == 2)
     %plot curvature
     [I,J] = find(data >=3*neg_max & data <= 3*pos_min);
     K = curvature(front_fld_intfc);
     figure,plot3(I,J,K,'.'),xlabel('x'), ylabel('y'), zlabel('fld intfc curvature')
     axis([0 g.N(1) 0 g.N(2) k_min_fld_intfc k_max_fld_intfc])
 end
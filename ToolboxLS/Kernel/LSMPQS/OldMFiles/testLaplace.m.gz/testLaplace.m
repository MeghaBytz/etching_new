function testLaplace

h = 0.1;
n = 1/h;
m = 1/h;

%BC - u=0 on top and sides of the square, u(x,0) = sin(pi*x)
y_low = zeros(m+1,1);
y_up  = zeros(m+1,1);
x_low = zeros(n+1,1);
x_up = zeros(n+1,1);

%for(i=1:(m+1))
 %   y_low(i) = sin(pi*i*h);
%end;


% Form problem Av=b

% b will be right hand side vector
N = (m-1)*(n-1)
%c = 0; % solving homogeneous problem u_xx + u_yy = 0
c=1;
b = c*h*h*ones(N,1);

a = ones(N,1);
A = -4*diag(a);

% incorporate BC in vector b and finish filling matrix A
% could have formed A by patching blocks
for(j=2:n)
   for(i=2:m)
        %compute appropriate index in b
        k = (m-1)*(j-2) + (i-1);
        %fprintf('i %d j %d k %d\n',i,j,k);
        
        if (i == 2)
            b(k) = b(k) - x_low(j);
        else
            k1 = k - 1;
            A(k,k1) = 1;
        end 
        
        if (i == m)
            b(k) = b(k) - x_up(j); 
        else
            k1 = k + 1;
            A(k,k1) = 1;
        end
        
        if (j == 2)
            b(k) = b(k) - y_low(i); 
        else
            k1 = k - (m-1);
            A(k,k1) = 1;
        end 
        
        if (j == n)
            b(k) = b(k) - y_up(i);
        else
            k1 = k + (m-1);
            A(k,k1) = 1;
        end
    end
end

%solve Av = b
[L U] = lu(A);
v = U\(L\b)
size(v)

%plotting only interior points
v = reshape(v,m-1,n-1); v = v'; % need to tranpose to get the plot of x & y right

%x = [h:h:(1-h)];
%y=  [h:h:(1-h)];
%[X Y] = meshgrid(x,y);
%plot3(X,Y,v)
mesh(v), xlabel('x'), ylabel('y')




function display_curvature(data,curv,mask,eps_front,eps_mask,OutFile)

%compute current curvature
 front = find( abs(data) < eps_front);
 k_avg = mean( curvature(front) )
 k_min =  min( curvature(front) )
 k_max =  max( curvature(front) )

 %curvature on fluid-fluid intfc (avoid fluid/grain space intfc)
 front_fld_intfc = find(( abs(data) < eps_front) & (mask < eps_mask));
 k_avg_fld_intfc = mean( curvature(front_fld_intfc) )
 k_min_fld_intfc = min( curvature(front_fld_intfc) )
 k_max_fld_intfc = max( curvature(front_fld_intfc) )

 if (nargin > 5)
     fid = fopen(OutFile,'w');
     fprintf(fid,'\nFront curvature (abs(data) < %g)\n',eps_front);
     fprintf(fid,'\tk_avg = %g\n\tk_min = %g\n\tk_max = %g\n',k_avg,k_min,k_max);
     fprintf(fid,'Fluid interface curvature ((abs(data) < %g) & (mask < %g)\n', eps_front,eps_mask);
     fprintf(fid,'\tk_avg_fld_intfc %g\n',k_avg_fld_intfc);
     fprintf(fid,'\tk_min_fld_intfc %g\n',k_min_fld_intfc);
     fprintf(fid,'\tk_max_fld_intfc %g\n',k_max_fld_intfc);
 end
 
 if(g.dim == 2)
     %plot curvature
     [I,J] = find(( abs(data) < eps_front) & (mask < eps_mask));
     K = curvature(front_fld_intfc);
     figure,plot3(I,J,K,'.'),xlabel('x'), ylabel('y'), zlabel('fld intfc curvature')
     axis([0 g.N(1) 0 g.N(2) k_min_fld_intfc k_max_fld_intfc])
 end